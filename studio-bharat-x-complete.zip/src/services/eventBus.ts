import { StudioEventMap } from '../types/studio';

type EventKey = keyof StudioEventMap;
type Listener<K extends EventKey> = (payload: StudioEventMap[K]) => void;

class StudioEventBus {
  private listeners = new Map<EventKey, Set<Listener<EventKey>>>();

  on<K extends EventKey>(event: K, listener: Listener<K>): () => void {
    let bucket = this.listeners.get(event);
    if (!bucket) {
      bucket = new Set();
      this.listeners.set(event, bucket);
    }
    bucket.add(listener as Listener<EventKey>);
    return () => this.off(event, listener);
  }

  once<K extends EventKey>(event: K, listener: Listener<K>): () => void {
    const wrapped: Listener<K> = (payload) => {
      this.off(event, wrapped);
      listener(payload);
    };
    return this.on(event, wrapped);
  }

  off<K extends EventKey>(event: K, listener: Listener<K>): void {
    const bucket = this.listeners.get(event);
    if (!bucket) return;
    bucket.delete(listener as Listener<EventKey>);
    if (bucket.size === 0) {
      this.listeners.delete(event);
    }
  }

  emit<K extends EventKey>(event: K, payload: StudioEventMap[K]): void {
    const bucket = this.listeners.get(event);
    if (!bucket || bucket.size === 0) return;
    for (const listener of Array.from(bucket)) {
      try {
        (listener as Listener<K>)(payload);
      } catch {
        // Keep studioBus resilient so one subscriber never breaks other rooms.
      }
    }
  }
}

export const studioBus = new StudioEventBus();
