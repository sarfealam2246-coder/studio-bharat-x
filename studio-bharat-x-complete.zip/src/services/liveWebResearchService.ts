import { ResearchSource } from '../types/studio';

const PER_SOURCE_TIMEOUT_MS = 4500;

export interface LiveWebResearchResult {
  query: string;
  findings: ResearchSource[];
  contextBlock: string;
  fetchedAt: number;
}

const RESEARCH_TRIGGER_REGEX =
  /\b(news|latest|today|trend|trends|trending|market|price|stock|crypto|weather|research|search|find|lookup|what is|who is|explain|compare|vs|history|release|update|github|repo|library|framework|documentation|stats|data|world|india|2025|2026)\b|(ताजा|ताज़ा|खबर|खबरें|न्यूज़|न्यूज|ट्रेंड|मार्केट|बाज़ार|बाजार|कीमत|भाव|रिसर्च|जानकारी|क्या है|कौन है|बताओ|खोजो|सर्च|तुलना|इतिहास|भारत)/i;

export function shouldRunLiveWebResearch(input: string): boolean {
  const trimmed = input.trim();
  if (trimmed.length < 4) return false;
  // Don't research pure API key pastes or short greetings
  if (/^(hi|hello|hey|namaste|नमस्ते|ok|thanks|धन्यवाद)$/i.test(trimmed)) return false;
  if (/^(AIza|AQ\.|gsk_|nvapi-|cfut_|ghp_|github_pat_)/i.test(trimmed)) return false;
  if (RESEARCH_TRIGGER_REGEX.test(trimmed)) return true;
  // Detailed informational questions ending with ? or longer queries
  if (trimmed.includes('?') && trimmed.length >= 16) return true;
  return false;
}

function cleanResearchQuery(raw: string): string {
  return raw
    .replace(/(?:please|can you|tell me about|search for|research|latest news on|बताओ|के बारे में|जानकारी दो)/gi, ' ')
    .replace(/[?!।]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120);
}

async function fetchJsonWithTimeout<T>(url: string, headers?: Record<string, string>): Promise<T | null> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), PER_SOURCE_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers,
      signal: controller.signal,
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    window.clearTimeout(timer);
  }
}

async function fetchWikipediaAndSummary(query: string): Promise<ResearchSource[]> {
  const hasDevanagari = /[\u0900-\u097F]/.test(query);
  const wikiHost = hasDevanagari ? 'hi.wikipedia.org' : 'en.wikipedia.org';
  const openSearchUrl = `https://${wikiHost}/w/api.php?action=opensearch&search=${encodeURIComponent(
    query
  )}&limit=3&namespace=0&format=json&origin=*`;

  const data = await fetchJsonWithTimeout<[string, string[], string[], string[]]>(openSearchUrl);
  const results: ResearchSource[] = [];

  if (Array.isArray(data) && Array.isArray(data[1])) {
    const titles = data[1];
    const descriptions = Array.isArray(data[2]) ? data[2] : [];
    const urls = Array.isArray(data[3]) ? data[3] : [];

    for (let i = 0; i < Math.min(3, titles.length); i++) {
      const title = titles[i];
      const url = urls[i];
      if (title && url) {
        results.push({
          title,
          url,
          snippet: descriptions[i] || `Wikipedia entry for ${title}`,
          provider: 'Wikipedia',
        });
      }
    }

    // Fetch Wikimedia REST summary for the top matched article for richer verified context
    const topTitle = titles[0];
    if (topTitle) {
      const summaryUrl = `https://${wikiHost}/api/rest_v1/page/summary/${encodeURIComponent(
        topTitle.replace(/\s+/g, '_')
      )}`;
      const summary = await fetchJsonWithTimeout<{
        title?: string;
        extract?: string;
        content_urls?: { desktop?: { page?: string } };
      }>(summaryUrl);

      if (summary?.extract) {
        results.unshift({
          title: summary.title || topTitle,
          url: summary.content_urls?.desktop?.page || urls[0] || `https://${wikiHost}`,
          snippet: summary.extract.slice(0, 320),
          provider: 'Wikimedia',
        });
      }
    }
  }

  return results;
}

async function fetchDuckDuckGoInstant(query: string): Promise<ResearchSource[]> {
  const ddgUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(
    query
  )}&format=json&no_html=1&skip_disambig=1`;

  const data = await fetchJsonWithTimeout<{
    Heading?: string;
    AbstractText?: string;
    AbstractURL?: string;
    RelatedTopics?: Array<{
      Text?: string;
      FirstURL?: string;
      Topics?: Array<{ Text?: string; FirstURL?: string }>;
    }>;
  }>(ddgUrl);

  if (!data) return [];
  const sources: ResearchSource[] = [];

  if (data.AbstractText && data.AbstractURL) {
    sources.push({
      title: data.Heading || query,
      url: data.AbstractURL,
      snippet: data.AbstractText.slice(0, 300),
      provider: 'DuckDuckGo',
    });
  }

  const topics = Array.isArray(data.RelatedTopics) ? data.RelatedTopics : [];
  for (const item of topics) {
    if (sources.length >= 3) break;
    if (item.Text && item.FirstURL) {
      sources.push({
        title: item.Text.split(' - ')[0].slice(0, 80),
        url: item.FirstURL,
        snippet: item.Text.slice(0, 220),
        provider: 'DuckDuckGo',
      });
    } else if (Array.isArray(item.Topics)) {
      for (const nested of item.Topics) {
        if (sources.length >= 3) break;
        if (nested.Text && nested.FirstURL) {
          sources.push({
            title: nested.Text.split(' - ')[0].slice(0, 80),
            url: nested.FirstURL,
            snippet: nested.Text.slice(0, 220),
            provider: 'DuckDuckGo',
          });
        }
      }
    }
  }

  return sources;
}

async function fetchGitHubRepositories(query: string): Promise<ResearchSource[]> {
  const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(
    query
  )}&sort=stars&order=desc&per_page=3`;

  const data = await fetchJsonWithTimeout<{
    items?: Array<{
      full_name?: string;
      html_url?: string;
      description?: string | null;
      stargazers_count?: number;
      language?: string | null;
    }>;
  }>(url, { Accept: 'application/vnd.github+json' });

  if (!data?.items?.length) return [];

  return data.items
    .filter((repo) => Boolean(repo.full_name && repo.html_url))
    .slice(0, 3)
    .map((repo) => ({
      title: `${repo.full_name}${repo.stargazers_count ? ` (★ ${repo.stargazers_count.toLocaleString()})` : ''}`,
      url: repo.html_url!,
      snippet: `${repo.language ? `[${repo.language}] ` : ''}${repo.description || 'GitHub repository'}`.slice(
        0,
        220
      ),
      provider: 'GitHub' as const,
    }));
}

export async function runLiveWebResearch(rawQuery: string): Promise<LiveWebResearchResult> {
  const query = cleanResearchQuery(rawQuery) || rawQuery.trim();
  const [wikiSettled, ddgSettled, ghSettled] = await Promise.allSettled([
    fetchWikipediaAndSummary(query),
    fetchDuckDuckGoInstant(query),
    fetchGitHubRepositories(query),
  ]);

  const combined: ResearchSource[] = [];
  if (wikiSettled.status === 'fulfilled') combined.push(...wikiSettled.value);
  if (ddgSettled.status === 'fulfilled') combined.push(...ddgSettled.value);
  if (ghSettled.status === 'fulfilled') combined.push(...ghSettled.value);

  // Deduplicate by URL and cap to 6 highest-signal findings
  const seenUrls = new Set<string>();
  const findings: ResearchSource[] = [];
  for (const item of combined) {
    if (!item.url || seenUrls.has(item.url)) continue;
    seenUrls.add(item.url);
    findings.push(item);
    if (findings.length >= 6) break;
  }

  const contextBlock =
    findings.length > 0
      ? `LIVE WEB RESEARCH FINDINGS (verified public data for "${query}"):\n${findings
          .map(
            (f, idx) =>
              `${idx + 1}. [${f.provider}] ${f.title} (${f.url})\n   Summary: ${f.snippet}`
          )
          .join('\n')}`
      : '';

  return {
    query,
    findings,
    contextBlock,
    fetchedAt: Date.now(),
  };
}
