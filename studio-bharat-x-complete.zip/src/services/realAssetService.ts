import { RealAppIcon, RealGamingAsset } from '../types/studio';

const VAULT_CATALOG_URL =
  'https://raw.githubusercontent.com/sarfealam2246-coder/sarfealam-3d-assets/main/catalog.json';
const POLYHAVEN_MODELS_URL = 'https://api.polyhaven.com/assets?t=models';
const OPENVERSE_IMAGES_URL = 'https://api.openverse.org/v1/images/';
const ICONIFY_SEARCH_URL = 'https://api.iconify.design/search';

const FETCH_TIMEOUT_MS = 5000;

let vaultCache: RealGamingAsset[] | null = null;
let polyHavenCache: RealGamingAsset[] | null = null;

function escapeRegex(token: string): string {
  return token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function tokenizeQuery(query: string): string[] {
  return query
    .toLowerCase()
    .split(/[^a-z0-9]+/i)
    .map((t) => t.trim())
    .filter((t) => t.length >= 2);
}

/**
 * Strict word-boundary token matching:
 * Searching "car" matches "car" or "cars" at true word boundaries ONLY —
 * NEVER "carrot", "carton", "cardboard", "carpet", or "cartoon".
 */
export function matchesStrictWordBoundary(query: string, candidateText: string): boolean {
  const tokens = tokenizeQuery(query);
  if (tokens.length === 0) return false;

  const normalizedHaystack = candidateText.toLowerCase().replace(/[_-]+/g, ' ');

  return tokens.every((token) => {
    const escaped = escapeRegex(token);
    const pattern = new RegExp(`(?:^|[^a-z0-9])${escaped}s?(?:[^a-z0-9]|$)`, 'i');
    return pattern.test(normalizedHaystack);
  });
}

async function fetchJsonWithTimeout<T>(url: string): Promise<T | null> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    window.clearTimeout(timer);
  }
}

function normalizeVaultCatalog(raw: unknown): RealGamingAsset[] {
  const results: RealGamingAsset[] = [];
  const items: Array<Record<string, unknown>> = [];

  if (Array.isArray(raw)) {
    for (const entry of raw) {
      if (entry && typeof entry === 'object') items.push(entry as Record<string, unknown>);
    }
  } else if (raw && typeof raw === 'object') {
    const obj = raw as Record<string, unknown>;
    const candidateArray = obj.assets ?? obj.models ?? obj.items;
    if (Array.isArray(candidateArray)) {
      for (const entry of candidateArray) {
        if (entry && typeof entry === 'object') items.push(entry as Record<string, unknown>);
      }
    } else {
      for (const [key, val] of Object.entries(obj)) {
        if (val && typeof val === 'object') {
          items.push({ id: key, ...(val as Record<string, unknown>) });
        }
      }
    }
  }

  for (const item of items) {
    const id = String(item.id ?? item.slug ?? item.name ?? '').trim();
    const name = String(item.name ?? item.title ?? id).trim();
    const assetUrl = String(item.url ?? item.glb ?? item.modelUrl ?? item.download ?? '').trim();
    const previewUrl = String(
      item.preview ?? item.thumbnail ?? item.thumb ?? item.image ?? ''
    ).trim();
    if (!name || (!assetUrl && !previewUrl)) continue;

    const rawTags = Array.isArray(item.tags)
      ? item.tags.map((t) => String(t))
      : typeof item.category === 'string'
        ? [item.category]
        : [];

    results.push({
      id: `vault_${id || name.toLowerCase().replace(/\s+/g, '_')}`,
      name,
      source: '3D Vault',
      kind: '3d-model',
      previewUrl,
      assetUrl: assetUrl || previewUrl,
      license: typeof item.license === 'string' ? item.license : 'Public 3D Vault',
      tags: rawTags,
    });
  }

  return results;
}

async function searchPublic3DVault(query: string): Promise<RealGamingAsset[]> {
  if (!vaultCache) {
    const data = await fetchJsonWithTimeout<unknown>(VAULT_CATALOG_URL);
    vaultCache = data ? normalizeVaultCatalog(data) : [];
  }

  return vaultCache
    .filter((asset) => {
      const text = `${asset.name} ${asset.id} ${asset.tags.join(' ')}`;
      return matchesStrictWordBoundary(query, text);
    })
    .slice(0, 8);
}

async function searchPolyHavenModels(query: string): Promise<RealGamingAsset[]> {
  if (!polyHavenCache) {
    const data = await fetchJsonWithTimeout<
      Record<
        string,
        {
          name?: string;
          categories?: string[];
          tags?: string[];
        }
      >
    >(POLYHAVEN_MODELS_URL);

    if (data && typeof data === 'object') {
      polyHavenCache = Object.entries(data).map(([slug, meta]) => ({
        id: `polyhaven_${slug}`,
        name: meta?.name || slug.replace(/_/g, ' '),
        source: 'PolyHaven' as const,
        kind: '3d-model' as const,
        previewUrl: `https://cdn.polyhaven.com/asset_img/thumbs/${encodeURIComponent(slug)}.png?height=240`,
        assetUrl: `https://polyhaven.com/a/${encodeURIComponent(slug)}`,
        license: 'CC0',
        tags: [...(meta?.categories ?? []), ...(meta?.tags ?? []), slug],
      }));
    } else {
      polyHavenCache = [];
    }
  }

  return polyHavenCache
    .filter((asset) => {
      const text = `${asset.name} ${asset.tags.join(' ')}`;
      return matchesStrictWordBoundary(query, text);
    })
    .slice(0, 8);
}

async function searchOpenverseSprites(query: string): Promise<RealGamingAsset[]> {
  const url = `${OPENVERSE_IMAGES_URL}?q=${encodeURIComponent(query)}&page_size=14`;
  const data = await fetchJsonWithTimeout<{
    results?: Array<{
      id?: string;
      title?: string;
      thumbnail?: string;
      url?: string;
      license?: string;
      tags?: Array<{ name?: string }>;
    }>;
  }>(url);

  if (!Array.isArray(data?.results)) return [];

  const matched: RealGamingAsset[] = [];
  for (const item of data.results) {
    const title = (item.title ?? '').trim();
    const preview = (item.thumbnail ?? item.url ?? '').trim();
    const assetUrl = (item.url ?? preview).trim();
    if (!title || !preview) continue;

    const tags = Array.isArray(item.tags)
      ? item.tags.map((t) => t.name ?? '').filter(Boolean)
      : [];

    if (!matchesStrictWordBoundary(query, `${title} ${tags.join(' ')}`)) {
      continue;
    }

    matched.push({
      id: `openverse_${item.id ?? matched.length}`,
      name: title.slice(0, 64),
      source: 'Openverse',
      kind: 'sprite',
      previewUrl: preview,
      assetUrl,
      license: item.license ? item.license.toUpperCase() : 'Openverse',
      tags: tags.slice(0, 5),
    });

    if (matched.length >= 8) break;
  }

  return matched;
}

export async function searchRealGamingAssets(query: string): Promise<RealGamingAsset[]> {
  const trimmed = query.trim();
  if (!trimmed) return [];

  const [vaultSettled, polySettled, openverseSettled] = await Promise.allSettled([
    searchPublic3DVault(trimmed),
    searchPolyHavenModels(trimmed),
    searchOpenverseSprites(trimmed),
  ]);

  const combined: RealGamingAsset[] = [];
  if (vaultSettled.status === 'fulfilled') combined.push(...vaultSettled.value);
  if (polySettled.status === 'fulfilled') combined.push(...polySettled.value);
  if (openverseSettled.status === 'fulfilled') combined.push(...openverseSettled.value);

  const seen = new Set<string>();
  return combined.filter((asset) => {
    if (seen.has(asset.id)) return false;
    seen.add(asset.id);
    return true;
  });
}

export async function searchIconifyIcons(query: string): Promise<RealAppIcon[]> {
  const trimmed = query.trim();
  if (!trimmed) return [];

  const url = `${ICONIFY_SEARCH_URL}?query=${encodeURIComponent(trimmed)}&limit=24`;
  const data = await fetchJsonWithTimeout<{ icons?: string[] }>(url);
  if (!Array.isArray(data?.icons)) return [];

  const icons: RealAppIcon[] = [];
  for (const iconId of data.icons) {
    const [prefix, name] = iconId.split(':');
    if (!prefix || !name) continue;
    icons.push({
      id: iconId,
      prefix,
      name,
      svgUrl: `https://api.iconify.design/${encodeURIComponent(prefix)}/${encodeURIComponent(
        name
      )}.svg?color=%23f4f5f7`,
    });
  }
  return icons;
}
