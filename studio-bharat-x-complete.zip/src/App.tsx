/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { FolderOpen, KeyRound, Shield } from 'lucide-react';
import { DepartmentRoom } from './components/DepartmentRoom';
import { MemoryModal } from './components/MemoryModal';
import { ProjectsModal } from './components/ProjectsModal';
import { SecretsPanel } from './components/SecretsPanel';
import { AdminExportPanel } from './components/AdminExportPanel';
import { VedaHub } from './components/VedaHub';
import { DEPARTMENT_META, ROOM_LABELS, UI_COPY } from './i18n/translations';
import { runVedaAiRouter } from './services/aiRouter';
import {
  loadGitHubReelConfig,
  loadUnreadCloudReelFlag,
  setUnreadCloudReelFlag,
  syncCloudReelsFromGitHubReleases,
} from './services/bhojpuriEditorService';
import {
  isAutoScheduleDue,
  loadBhojpuriSchedule,
  loadCharacterVault,
  markBhojpuriStoryRead,
  runBhojpuriResearchAndStoryPipeline,
} from './services/bhojpuriReelsService';
import {
  speakWithStudioVoice,
  stopStudioSpeech,
} from './services/cloudTtsService';
import {
  isDictationSupported,
  pauseDictationTemporarily,
  startDictation,
  stopDictation,
} from './services/dictationService';
import {
  detectAndStorePastedApiKey,
  extractDynamicApiUrlRequest,
  testAndSaveDynamicSkill,
} from './services/dynamicToolsService';
import { studioBus } from './services/eventBus';
import {
  startLiveSession,
  stopLiveSession,
} from './services/geminiLiveService';
import {
  runLiveWebResearch,
  shouldRunLiveWebResearch,
} from './services/liveWebResearchService';
import {
  addMemoryRule,
  extractExplicitMemoryFromMessage,
  listMemoryRules,
} from './services/memoryService';
import {
  createNewProjectFile,
  createProject,
  listProjects,
  saveProject,
} from './services/projectStoreService';
import { countConfiguredSecrets, loadSecretsVault } from './services/secretsService';
import { runStudioCoderBuild } from './services/studioCoderService';
import {
  analyzeVedaArchitectIntent,
  buildLocalLockedStepPlan,
  buildNonBlockingOfflineReply,
  detectBhojpuriVedaCommand,
  formatLockedPlanMarkdown,
  switchToDepartmentViaBus,
} from './services/vedaArchitectService';
import {
  BhojpuriVedaCommandAction,
  BrainPreference,
  DepartmentId,
  DepartmentPreviewState,
  DictationStatus,
  Language,
  LiveSessionStatus,
  LockedStepPlan,
  MemoryRule,
  ResearchSource,
  RoomId,
  SecretsVaultState,
  StudioProject,
  VedaMessage,
  VoicePersona,
  VoiceSettings,
  VoiceSpeed,
} from './types/studio';

const HANDS_FREE_WATCHDOG_MS = 15_000;

function createInitialPreviewStates(): Record<DepartmentId, DepartmentPreviewState> {
  return {
    gaming: {
      department: 'gaming',
      mode: 'expanded',
      viewportPreset: 'canvas',
      selectedFileId: null,
      revision: 1,
      stageZoom: 1,
    },
    apps: {
      department: 'apps',
      mode: 'expanded',
      viewportPreset: 'mobile',
      selectedFileId: null,
      revision: 1,
      stageZoom: 1,
    },
    bhojpuri: {
      department: 'bhojpuri',
      mode: 'expanded',
      viewportPreset: 'reel',
      selectedFileId: null,
      revision: 1,
      stageZoom: 1,
    },
    agent: {
      department: 'agent',
      mode: 'expanded',
      viewportPreset: 'mobile',
      selectedFileId: null,
      revision: 1,
      stageZoom: 1,
    },
  };
}

function createInitialMessages(language: Language): VedaMessage[] {
  return [
    {
      id: 'veda_welcome',
      role: 'veda',
      timestamp: Date.now(),
      text:
        language === 'hi'
          ? 'STUDIO BHARAT X में आपका स्वागत है। मैं VEDA हूँ — किसी भी विभाग में जाने के लिए ऊपर कार्ड चुनें, या रिसर्च, प्लानिंग, गेम/ऐप बिल्ड, API स्किल या सीधे अपनी API कुंजी पेस्ट करें।'
          : 'Welcome to STUDIO BHARAT X. I am VEDA — pick any studio department card above, ask me to build a game or commercial app, run live web research, lock step plans, connect a REST API URL, or paste an API key directly into chat.',
    },
  ];
}

const BOTTOM_TABS: Array<{ id: RoomId; emoji: string }> = [
  { id: 'veda', emoji: '🏠' },
  { id: 'gaming', emoji: '🎮' },
  { id: 'apps', emoji: '📱' },
  { id: 'bhojpuri', emoji: '🎬' },
  { id: 'agent', emoji: '🤖' },
];

export default function App() {
  const [activeRoom, setActiveRoom] = useState<RoomId>('veda');
  const [language, setLanguage] = useState<Language>('en');
  const [vault, setVault] = useState<SecretsVaultState>(() => loadSecretsVault());

  const [secretsOpen, setSecretsOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [projectsOpen, setProjectsOpen] = useState(false);
  const [memoryOpen, setMemoryOpen] = useState(false);
  const [projectsFilter, setProjectsFilter] = useState<DepartmentId | 'all'>('all');

  const [projects, setProjects] = useState<StudioProject[]>([]);
  const [activeProjectIds, setActiveProjectIds] = useState<Record<DepartmentId, string | null>>({
    gaming: null,
    apps: null,
    bhojpuri: null,
    agent: null,
  });
  const [previewStates, setPreviewStates] = useState<Record<DepartmentId, DepartmentPreviewState>>(
    () => createInitialPreviewStates()
  );

  const [vedaMessages, setVedaMessages] = useState<VedaMessage[]>(() =>
    createInitialMessages('en')
  );
  const [vedaPrefillDraft, setVedaPrefillDraft] = useState<string | null>(null);

  // Part 2 Voice, Live & Hands-Free State
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    voiceReplyEnabled: true,
    handsFreeEnabled: false,
    persona: 'Aoede',
    speed: 1.0,
  });
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [dictationStatus, setDictationStatus] = useState<DictationStatus>('idle');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [liveStatus, setLiveStatus] = useState<LiveSessionStatus>('idle');
  const [liveKeySlot, setLiveKeySlot] = useState<number | undefined>(undefined);
  const [voiceNotice, setVoiceNotice] = useState<string | null>(null);

  // Part 3 Intelligence, Brain Selector & Permanent Memory State
  const [brainPreference, setBrainPreference] = useState<BrainPreference>('auto');
  const [memoryRules, setMemoryRules] = useState<MemoryRule[]>([]);
  const [thinkingPhase, setThinkingPhase] = useState<'idle' | 'researching' | 'thinking'>('idle');

  // Part 4 Isolated Gaming & Apps Coder State (strictly keyed per department)
  const [buildStepByDept, setBuildStepByDept] = useState<Record<DepartmentId, number>>({
    gaming: 1,
    apps: 1,
    bhojpuri: 1,
    agent: 1,
  });
  const [isBuildingByDept, setIsBuildingByDept] = useState<Record<DepartmentId, boolean>>({
    gaming: false,
    apps: false,
    bhojpuri: false,
    agent: false,
  });
  const [buildStatusByDept, setBuildStatusByDept] = useState<Record<DepartmentId, string | null>>({
    gaming: null,
    apps: null,
    bhojpuri: null,
    agent: null,
  });

  // Part 5 & 6 Bhojpuri Reels Auto-Schedule, New Story / New Reel Ready Badges & VEDA Commands
  const [hasNewBhojpuriStory, setHasNewBhojpuriStory] = useState<boolean>(
    () => loadBhojpuriSchedule().hasUnreadStory
  );
  const [hasNewBhojpuriReel, setHasNewBhojpuriReel] = useState<boolean>(() =>
    loadUnreadCloudReelFlag()
  );
  const [pendingBhojpuriCommand, setPendingBhojpuriCommand] = useState<{
    action: BhojpuriVedaCommandAction;
    topic?: string;
  } | null>(null);
  const bhojpuriAutoRunningRef = useRef(false);

  // Refs for fresh state inside async callbacks & the 15s Hands-Free watchdog
  const voiceSettingsRef = useRef<VoiceSettings>(voiceSettings);
  const languageRef = useRef<Language>(language);
  const brainPreferenceRef = useRef<BrainPreference>(brainPreference);
  const vedaMessagesRef = useRef<VedaMessage[]>(vedaMessages);
  const projectsRef = useRef<StudioProject[]>(projects);
  const activeProjectIdsRef = useRef<Record<DepartmentId, string | null>>(activeProjectIds);
  const buildStepByDeptRef = useRef<Record<DepartmentId, number>>(buildStepByDept);
  const isSpeakingRef = useRef<boolean>(false);
  const isListeningRef = useRef<boolean>(false);
  const isThinkingRef = useRef<boolean>(false);
  const liveStatusRef = useRef<LiveSessionStatus>('idle');
  const noticeTimerRef = useRef<number | null>(null);

  useEffect(() => {
    voiceSettingsRef.current = voiceSettings;
  }, [voiceSettings]);

  useEffect(() => {
    languageRef.current = language;
  }, [language]);

  useEffect(() => {
    brainPreferenceRef.current = brainPreference;
  }, [brainPreference]);

  useEffect(() => {
    vedaMessagesRef.current = vedaMessages;
  }, [vedaMessages]);

  useEffect(() => {
    projectsRef.current = projects;
  }, [projects]);

  useEffect(() => {
    activeProjectIdsRef.current = activeProjectIds;
  }, [activeProjectIds]);

  useEffect(() => {
    buildStepByDeptRef.current = buildStepByDept;
  }, [buildStepByDept]);

  useEffect(() => {
    isListeningRef.current = dictationStatus === 'listening' || dictationStatus === 'rearming';
  }, [dictationStatus]);

  useEffect(() => {
    liveStatusRef.current = liveStatus;
  }, [liveStatus]);

  const t = UI_COPY[language];
  const configuredSecrets = countConfiguredSecrets(vault);
  const activeMemoryCount = memoryRules.filter((r) => r.active).length;

  const showTransientVoiceNotice = useCallback((message: string) => {
    setVoiceNotice(message);
    if (noticeTimerRef.current !== null) {
      window.clearTimeout(noticeTimerRef.current);
    }
    noticeTimerRef.current = window.setTimeout(() => {
      setVoiceNotice(null);
      noticeTimerRef.current = null;
    }, 5500);
  }, []);

  const refreshProjects = useCallback(async () => {
    const loaded = await listProjects();
    setProjects(loaded);
    setActiveProjectIds((prev) => {
      const next = { ...prev };
      (['gaming', 'apps', 'bhojpuri', 'agent'] as DepartmentId[]).forEach((dept) => {
        const currentId = prev[dept];
        const stillExists = currentId && loaded.some((p) => p.id === currentId);
        if (!stillExists) {
          const latestForDept = loaded.find((p) => p.department === dept);
          next[dept] = latestForDept?.id ?? null;
        }
      });
      return next;
    });
  }, []);

  useEffect(() => {
    void refreshProjects();
    void listMemoryRules().then((loadedRules) => setMemoryRules(loadedRules));
  }, [refreshProjects]);

  const navigateRoom = useCallback((room: RoomId, source = 'ui') => {
    setActiveRoom(room);
    studioBus.emit('room:change', { room, source });
  }, []);

  useEffect(() => {
    const offRoom = studioBus.on('room:change', ({ room }) => {
      setActiveRoom(room);
    });
    const offSecrets = studioBus.on('secrets:open', () => {
      setSecretsOpen(true);
    });
    const offProjects = studioBus.on('projects:open', ({ department }) => {
      setProjectsFilter(department ?? 'all');
      setProjectsOpen(true);
    });
    const offNotice = studioBus.on('voice:notice', ({ message }) => {
      showTransientVoiceNotice(message);
    });
    const offSpeaking = studioBus.on('voice:speakingChange', ({ speaking, messageId }) => {
      isSpeakingRef.current = speaking;
      setSpeakingMessageId(speaking ? messageId : null);
    });
    const offLive = studioBus.on('voice:liveStatus', ({ status, keySlot }) => {
      liveStatusRef.current = status;
      setLiveStatus(status);
      setLiveKeySlot(keySlot);
    });
    const offBhojpuriReady = studioBus.on('bhojpuri:storyReady', () => {
      setHasNewBhojpuriStory(true);
    });
    const offBhojpuriReelReady = studioBus.on('bhojpuri:reelReady', () => {
      setHasNewBhojpuriReel(true);
    });
    const offBhojpuriCommand = studioBus.on('bhojpuri:command', (payload) => {
      setPendingBhojpuriCommand(payload);
    });
    return () => {
      offRoom();
      offSecrets();
      offProjects();
      offNotice();
      offSpeaking();
      offLive();
      offBhojpuriReady();
      offBhojpuriReelReady();
      offBhojpuriCommand();
    };
  }, [showTransientVoiceNotice]);

  // Part 5 & 6 Non-Blocking Bhojpuri Auto-Schedule & GitHub Releases Cloud Reel Check
  useEffect(() => {
    const checkAndRunSchedule = () => {
      // Check GitHub Releases for completed 24/7 Cloud FFmpeg MP4 reels
      const ghCfg = loadGitHubReelConfig();
      if (ghCfg.owner && ghCfg.repo) {
        void syncCloudReelsFromGitHubReleases(ghCfg);
      }

      if (bhojpuriAutoRunningRef.current) return;
      const sched = loadBhojpuriSchedule();
      if (!isAutoScheduleDue(sched)) return;

      const currentVault = loadSecretsVault();
      const hasAnyAiKey =
        currentVault.geminiKeys.some((k) => Boolean(k.trim())) ||
        currentVault.otherAiKeys.some((e) => Boolean(e.apiKey.trim()));
      if (!hasAnyAiKey) return;

      bhojpuriAutoRunningRef.current = true;
      void runBhojpuriResearchAndStoryPipeline({
        characters: loadCharacterVault(),
        language: languageRef.current,
        markAsAutoScheduled: true,
      }).finally(() => {
        bhojpuriAutoRunningRef.current = false;
      });
    };

    const initialTimer = window.setTimeout(checkAndRunSchedule, 2500);
    const intervalId = window.setInterval(checkAndRunSchedule, 15 * 60 * 1000);
    return () => {
      window.clearTimeout(initialTimer);
      window.clearInterval(intervalId);
    };
  }, []);

  const handleProjectSaved = useCallback((saved: StudioProject) => {
    setProjects((prev) => {
      const rest = prev.filter((p) => p.id !== saved.id);
      const next = [saved, ...rest].sort((a, b) => b.updatedAt - a.updatedAt);
      projectsRef.current = next;
      return next;
    });
    setActiveProjectIds((prev) => {
      const next = { ...prev, [saved.department]: saved.id };
      activeProjectIdsRef.current = next;
      return next;
    });
  }, []);

  // Core Part 4 Multi-File AI Coder Runner (used both inside DepartmentRoom AND by VEDA Direct Delegation)
  const handleRunCoderStep = useCallback(
    async (params: {
      department: 'gaming' | 'apps';
      prompt: string;
      stepNumber: number;
      fixErrorContext?: string;
      isAutoFix?: boolean;
      overrideProject?: StudioProject | null;
      postDelegationToVeda?: boolean;
    }): Promise<boolean> => {
      const {
        department,
        prompt,
        stepNumber,
        fixErrorContext,
        isAutoFix,
        overrideProject,
        postDelegationToVeda,
      } = params;

      const currentProjId = activeProjectIdsRef.current[department];
      const currentProject =
        overrideProject !== undefined
          ? overrideProject
          : currentProjId
            ? projectsRef.current.find((p) => p.id === currentProjId) ?? null
            : null;

      setIsBuildingByDept((prev) => ({ ...prev, [department]: true }));
      setBuildStatusByDept((prev) => ({
        ...prev,
        [department]: isAutoFix
          ? languageRef.current === 'hi'
            ? 'ऑटो-फ़िक्स कोड सुधार रहा है...'
            : 'Auto-Fix analyzing errors & updating files...'
          : languageRef.current === 'hi'
            ? `Step ${stepNumber} बिल्ड हो रहा है...`
            : `Building Step ${stepNumber} (checkpoint saved)...`,
      }));

      try {
        const result = await runStudioCoderBuild({
          department,
          project: currentProject,
          prompt,
          stepNumber,
          language: languageRef.current,
          fixErrorContext,
        });

        handleProjectSaved(result.project);

        const htmlFile = result.project.files.find((f) => f.path.toLowerCase() === 'index.html');
        setPreviewStates((prevAll) => ({
          ...prevAll,
          [department]: {
            ...prevAll[department],
            mode: prevAll[department].mode === 'folded' ? 'expanded' : prevAll[department].mode,
            selectedFileId: htmlFile?.id ?? result.project.files[0]?.id ?? null,
            revision: prevAll[department].revision + 1,
          },
        }));

        const statusLine = result.ok
          ? `${result.summary}${result.providerUsed ? ` · ${result.providerUsed}` : ''}`
          : result.summary;

        setBuildStatusByDept((prev) => ({ ...prev, [department]: statusLine }));

        if (postDelegationToVeda) {
          const deptLabel = DEPARTMENT_META[department].cardTitle[languageRef.current];
          const vedaMsg: VedaMessage = {
            id: `veda_build_${Date.now().toString(36)}`,
            role: 'veda',
            timestamp: Date.now(),
            providerUsed: result.providerUsed,
            text: result.ok
              ? languageRef.current === 'hi'
                ? `${deptLabel} Step ${stepNumber} पूरा हुआ: ${result.summary}\nआइसोलेटेड प्रीव्यू खुल गया है — आगे बढ़ने के लिए Approve करें या बदलाव बोलें।`
                : `${deptLabel} Step ${stepNumber} complete: ${result.summary}\nThe isolated preview is live — approve to advance or tap 🔄 बदलो to revise.`
              : result.summary,
            delegatedBuild: {
              department,
              projectId: result.project.id,
              stepNumber,
              prompt,
              providerUsed: result.providerUsed,
            },
            actionModal: !result.ok && result.noKeysConfigured ? 'secrets' : undefined,
          };
          setVedaMessages((prev) => [...prev, vedaMsg]);
        }

        return result.ok;
      } finally {
        setIsBuildingByDept((prev) => ({ ...prev, [department]: false }));
      }
    },
    [handleProjectSaved]
  );

  const handleApproveNextStep = useCallback(
    (department: 'gaming' | 'apps', explicitStep?: number) => {
      const nextStep = explicitStep ?? buildStepByDeptRef.current[department] + 1;
      setBuildStepByDept((prev) => ({ ...prev, [department]: nextStep }));
      setPreviewStates((prevAll) => ({
        ...prevAll,
        [department]: {
          ...prevAll[department],
          mode: 'expanded',
        },
      }));
      switchToDepartmentViaBus(department, 'approve-next-step');

      const prompt =
        languageRef.current === 'hi'
          ? `Step ${nextStep}: पिछले कोड को सुरक्षित रखते हुए अगले महत्वपूर्ण फ़ीचर, पॉलिश और इंटरैक्टिव सुधार जोड़ें।`
          : `Step ${nextStep}: Preserve all prior working code and implement the next logical feature milestone, visual polish, and responsive UX upgrade.`;

      void handleRunCoderStep({
        department,
        prompt,
        stepNumber: nextStep,
        postDelegationToVeda: true,
      });
    },
    [handleRunCoderStep]
  );

  const handleReviseDelegatedBuild = useCallback((department: 'gaming' | 'apps') => {
    const deptWord = department === 'gaming' ? 'Gaming' : 'Commercial App';
    setVedaPrefillDraft(
      languageRef.current === 'hi'
        ? `${deptWord} में यह बदलाव करो: `
        : `Revise ${deptWord}: `
    );
    navigateRoom('veda', 'revise-build');
  }, [navigateRoom]);

  // Ref for sendMessage so dictation callbacks always invoke the latest async pipeline
  const sendVedaMessageRef = useRef<(text: string) => void>(() => {});

  const armHandsFreeDictation = useCallback(() => {
    if (!voiceSettingsRef.current.handsFreeEnabled) return;
    if (isSpeakingRef.current || isThinkingRef.current || liveStatusRef.current !== 'idle') return;

    void startDictation({
      language: languageRef.current,
      isHandsFreeActive: () => voiceSettingsRef.current.handsFreeEnabled,
      canListenNow: () =>
        voiceSettingsRef.current.handsFreeEnabled &&
        !isSpeakingRef.current &&
        !isThinkingRef.current &&
        liveStatusRef.current === 'idle',
      onInterimTranscript: (interim) => setInterimTranscript(interim),
      onFinalTranscript: (spokenText) => {
        setInterimTranscript('');
        sendVedaMessageRef.current(spokenText);
      },
      onStatusChange: (nextStatus) => {
        setDictationStatus(nextStatus);
        isListeningRef.current = nextStatus === 'listening' || nextStatus === 'rearming';
      },
    });
  }, []);

  const speakReplyAndResumeHandsFree = useCallback(
    (replyMsg: VedaMessage) => {
      const settings = voiceSettingsRef.current;
      if (settings.voiceReplyEnabled && liveStatusRef.current === 'idle') {
        void speakWithStudioVoice(replyMsg.text, {
          persona: settings.persona,
          speed: settings.speed,
          language: languageRef.current,
          messageId: replyMsg.id,
        }).finally(() => {
          if (voiceSettingsRef.current.handsFreeEnabled && liveStatusRef.current === 'idle') {
            window.setTimeout(() => armHandsFreeDictation(), 350);
          }
        });
      } else if (settings.handsFreeEnabled && liveStatusRef.current === 'idle') {
        window.setTimeout(() => armHandsFreeDictation(), 350);
      }
    },
    [armHandsFreeDictation]
  );

  const handleSendVedaMessage = useCallback(
    (text: string) => {
      const cleaned = text.trim();
      if (!cleaned || isThinkingRef.current) return;

      void (async () => {
        isThinkingRef.current = true;
        pauseDictationTemporarily();
        setInterimTranscript('');

        const now = Date.now();
        const lang = languageRef.current;

        try {
          // 1. Smart Chat-Paste Auto-Routing for API Keys
          const keyPaste = detectAndStorePastedApiKey(cleaned, lang);
          if (keyPaste) {
            setVault(keyPaste.updatedVault);
            const userMsg: VedaMessage = {
              id: `user_${now.toString(36)}`,
              role: 'user',
              text: `[Pasted ${keyPaste.targetLabel}: ${keyPaste.maskedKey}]`,
              timestamp: now,
            };
            const vedaReply: VedaMessage = {
              id: `veda_${(now + 1).toString(36)}`,
              role: 'veda',
              text: keyPaste.confirmationText,
              timestamp: now + 1,
              actionModal: 'secrets',
            };
            setVedaMessages((prev) => [...prev, userMsg, vedaReply]);
            isThinkingRef.current = false;
            speakReplyAndResumeHandsFree(vedaReply);
            return;
          }

          const userMsg: VedaMessage = {
            id: `user_${now.toString(36)}`,
            role: 'user',
            text: cleaned,
            timestamp: now,
          };
          const historySnapshot = [...vedaMessagesRef.current, userMsg];
          setVedaMessages(historySnapshot);

          // 2. Dynamic API / Skill Tool Builder
          const dynamicApiUrl = extractDynamicApiUrlRequest(cleaned);
          if (dynamicApiUrl) {
            setThinkingPhase('thinking');
            const skill = await testAndSaveDynamicSkill(dynamicApiUrl, cleaned);
            const replyText =
              skill.lastStatus === 'ok'
                ? lang === 'hi'
                  ? `✅ नया API टूल "${skill.name}" (HTTP ${skill.lastHttpStatus ?? 200}) सफलतापूर्वक टेस्ट होकर studio_bharat_x_skills_v1 में सेव हो गया है।`
                  : `✅ Tested and saved dynamic API skill "${skill.name}" (HTTP ${skill.lastHttpStatus ?? 200}) into studio_bharat_x_skills_v1.`
                : lang === 'hi'
                  ? `API टूल "${skill.name}" studio_bharat_x_skills_v1 में सेव हो गया है, लेकिन लाइव टेस्ट में चेतावनी मिली: ${skill.lastSnippet}`
                  : `Saved API skill "${skill.name}" to studio_bharat_x_skills_v1, though the live 5s probe returned: ${skill.lastSnippet}`;

            const vedaReply: VedaMessage = {
              id: `veda_${Date.now().toString(36)}`,
              role: 'veda',
              text: replyText,
              timestamp: Date.now(),
              savedSkill: skill,
            };
            setVedaMessages((prev) => [...prev, vedaReply]);
            setThinkingPhase('idle');
            isThinkingRef.current = false;
            speakReplyAndResumeHandsFree(vedaReply);
            return;
          }

          // 3. Automatic silent permanent memory extraction
          let learnedRuleSaved: string | undefined;
          const explicitRule = extractExplicitMemoryFromMessage(cleaned);
          if (explicitRule) {
            const memRes = await addMemoryRule({
              text: explicitRule,
              category: 'rule',
              source: 'auto',
            });
            setMemoryRules(memRes.allRules);
            if (memRes.saved && memRes.rule) {
              learnedRuleSaved = memRes.rule.text;
            }
          }

          // 4. VEDA Architect Intent Analysis
          const intent = analyzeVedaArchitectIntent(cleaned, lang);

          if (intent.ambiguousBuild && intent.clarifyQuestion) {
            const vedaReply: VedaMessage = {
              id: `veda_${Date.now().toString(36)}`,
              role: 'veda',
              text: intent.clarifyQuestion,
              timestamp: Date.now(),
              clarifyRooms: intent.clarifyRooms,
              learnedRuleSaved,
            };
            setVedaMessages((prev) => [...prev, vedaReply]);
            isThinkingRef.current = false;
            speakReplyAndResumeHandsFree(vedaReply);
            return;
          }

          if (intent.directModal) {
            if (intent.directModal === 'secrets') setSecretsOpen(true);
            if (intent.directModal === 'projects') {
              setProjectsFilter('all');
              setProjectsOpen(true);
            }
            if (intent.directModal === 'memory') setMemoryOpen(true);

            const vedaReply: VedaMessage = {
              id: `veda_${Date.now().toString(36)}`,
              role: 'veda',
              text:
                intent.directModal === 'secrets'
                  ? lang === 'hi'
                    ? 'Secrets & Connections Vault खोल दिया गया है।'
                    : 'Opened the Secrets & Connections Vault.'
                  : intent.directModal === 'memory'
                    ? lang === 'hi'
                      ? 'VEDA स्थायी मेमोरी पैनल खोल दिया गया है।'
                      : 'Opened the VEDA Permanent Memory panel.'
                    : lang === 'hi'
                      ? 'मल्टी-प्रोजेक्ट वर्कस्पेस खोल दिया गया है।'
                      : 'Opened the Multi-Project Workspace.',
              timestamp: Date.now(),
              actionModal: intent.directModal,
              learnedRuleSaved,
            };
            setVedaMessages((prev) => [...prev, vedaReply]);
            isThinkingRef.current = false;
            speakReplyAndResumeHandsFree(vedaReply);
            return;
          }

          // 4b. Part 6 Direct VEDA Voice/Text Commands for Bhojpuri Research, Cloud Render & Facebook Publish
          const bhojpuriCmd = !intent.wantsStepPlan
            ? detectBhojpuriVedaCommand(intent.normalizedText)
            : null;
          if (bhojpuriCmd) {
            setPreviewStates((prevAll) => ({
              ...prevAll,
              bhojpuri: { ...prevAll.bhojpuri, mode: 'expanded' },
            }));
            setPendingBhojpuriCommand(bhojpuriCmd);
            studioBus.emit('bhojpuri:command', bhojpuriCmd);
            switchToDepartmentViaBus('bhojpuri', 'veda-bhojpuri-command');

            const cmdReplyText =
              bhojpuriCmd.action === 'research'
                ? lang === 'hi'
                  ? 'भोजपुरी रील्स कक्ष में लाइव ट्रेंड रिसर्च और नई कॉमेडी स्क्रिप्ट शुरू कर दी गई है।'
                  : 'Opened Bhojpuri Reels and started the live trend research & comedy script pipeline.'
                : bhojpuriCmd.action === 'cloud_render'
                  ? lang === 'hi'
                    ? 'भोजपुरी 9:16 वीडियो एडिटर खोलकर 24/7 Cloud FFmpeg Render ट्रिगर कर दिया गया है।'
                    : 'Opened the Bhojpuri 9:16 Video Editor and triggered 24/7 Cloud FFmpeg Render.'
                  : lang === 'hi'
                    ? 'भोजपुरी एडिटर खोलकर Facebook Page Reels पब्लिश फ़्लो शुरू कर दिया गया है।'
                    : 'Opened the Bhojpuri Reels Publisher and started the Facebook Page Reels publish flow.';

            const vedaReply: VedaMessage = {
              id: `veda_bhj_${Date.now().toString(36)}`,
              role: 'veda',
              text: cmdReplyText,
              timestamp: Date.now(),
              actionRoom: 'bhojpuri',
              learnedRuleSaved,
            };
            setVedaMessages((prev) => [...prev, vedaReply]);
            isThinkingRef.current = false;
            speakReplyAndResumeHandsFree(vedaReply);
            return;
          }

          // 4c. Part 4 Direct Department Delegation for Gaming & Commercial Apps build/revise intents
          const isExplicitBuildOrRevise =
            /\b(build|create|make|generate|revise|update|add|banao|banana|badlo|बनाओ|बनाना|बदलाव)\b/i.test(
              intent.normalizedText
            );
          if (
            !intent.wantsStepPlan &&
            isExplicitBuildOrRevise &&
            (intent.directDepartment === 'gaming' || intent.directDepartment === 'apps')
          ) {
            const targetDept = intent.directDepartment;
            const currentStep = buildStepByDeptRef.current[targetDept];
            setPreviewStates((prevAll) => ({
              ...prevAll,
              [targetDept]: { ...prevAll[targetDept], mode: 'expanded' },
            }));
            switchToDepartmentViaBus(targetDept, 'veda-direct-delegation');
            isThinkingRef.current = false;

            await handleRunCoderStep({
              department: targetDept,
              prompt: intent.normalizedText,
              stepNumber: currentStep,
              postDelegationToVeda: true,
            });
            return;
          }

          // 5. Free Parallel Live Web Research Engine
          let researchFindings: ResearchSource[] = [];
          let researchContextBlock = '';
          if (shouldRunLiveWebResearch(intent.normalizedText)) {
            setThinkingPhase('researching');
            const research = await runLiveWebResearch(intent.normalizedText);
            researchFindings = research.findings;
            researchContextBlock = research.contextBlock;
          }

          // 6. Auto-Rotating Multi-Provider AI Router
          setThinkingPhase('thinking');
          const aiRes = await runVedaAiRouter({
            userMessage: cleaned,
            normalizedMessage: intent.normalizedText,
            history: historySnapshot.slice(0, -1),
            language: lang,
            brainPreference: brainPreferenceRef.current,
            researchContext: researchContextBlock || undefined,
            requestLockedPlan: intent.wantsStepPlan,
            planDepartmentHint: intent.planDepartmentHint,
          });

          if (aiRes.learnedRule) {
            const memRes = await addMemoryRule({
              text: aiRes.learnedRule,
              category: 'preference',
              source: 'auto',
            });
            setMemoryRules(memRes.allRules);
            if (memRes.saved && memRes.rule && !learnedRuleSaved) {
              learnedRuleSaved = memRes.rule.text;
            }
          }

          const resolvedLockedPlan: LockedStepPlan | undefined =
            aiRes.lockedPlan ??
            (intent.wantsStepPlan
              ? buildLocalLockedStepPlan(intent.normalizedText, intent.planDepartmentHint, lang)
              : undefined);

          const finalReplyText = aiRes.ok
            ? aiRes.reply
            : buildNonBlockingOfflineReply({
                language: lang,
                noKeysConfigured: Boolean(aiRes.noKeysConfigured),
                findings: researchFindings,
                directDepartment: intent.directDepartment,
                wantsStepPlan: intent.wantsStepPlan,
              });

          const targetDept: DepartmentId | undefined = intent.shouldAutoSwitchRoom
            ? intent.directDepartment
            : !resolvedLockedPlan
              ? aiRes.routeDepartment ?? intent.directDepartment
              : undefined;

          const vedaReply: VedaMessage = {
            id: `veda_${Date.now().toString(36)}`,
            role: 'veda',
            text: finalReplyText,
            timestamp: Date.now(),
            providerUsed: aiRes.providerUsed,
            sources: researchFindings.length > 0 ? researchFindings : undefined,
            lockedPlan: resolvedLockedPlan,
            actionRoom: resolvedLockedPlan ? undefined : targetDept,
            actionModal: !aiRes.ok && aiRes.noKeysConfigured && !targetDept ? 'secrets' : undefined,
            learnedRuleSaved,
          };

          setVedaMessages((prev) => [...prev, vedaReply]);
          setThinkingPhase('idle');
          isThinkingRef.current = false;

          if (intent.shouldAutoSwitchRoom && intent.directDepartment && !resolvedLockedPlan) {
            switchToDepartmentViaBus(intent.directDepartment, 'veda-architect');
          }

          speakReplyAndResumeHandsFree(vedaReply);
        } catch {
          setThinkingPhase('idle');
          isThinkingRef.current = false;
          if (voiceSettingsRef.current.handsFreeEnabled && liveStatusRef.current === 'idle') {
            window.setTimeout(() => armHandsFreeDictation(), 400);
          }
        }
      })();
    },
    [armHandsFreeDictation, handleRunCoderStep, speakReplyAndResumeHandsFree]
  );

  useEffect(() => {
    sendVedaMessageRef.current = handleSendVedaMessage;
  }, [handleSendVedaMessage]);

  // 15-second Hands-Free Watchdog
  useEffect(() => {
    const intervalId = window.setInterval(() => {
      if (
        voiceSettingsRef.current.handsFreeEnabled &&
        !isListeningRef.current &&
        !isSpeakingRef.current &&
        !isThinkingRef.current &&
        liveStatusRef.current === 'idle'
      ) {
        armHandsFreeDictation();
      }
    }, HANDS_FREE_WATCHDOG_MS);

    return () => window.clearInterval(intervalId);
  }, [armHandsFreeDictation]);

  useEffect(() => {
    return () => {
      if (noticeTimerRef.current !== null) {
        window.clearTimeout(noticeTimerRef.current);
      }
      stopDictation();
      stopStudioSpeech();
      stopLiveSession();
    };
  }, []);

  const handleToggleLanguage = () => {
    const next: Language = language === 'en' ? 'hi' : 'en';
    setLanguage(next);
    languageRef.current = next;
    studioBus.emit('language:change', { language: next });

    if (voiceSettingsRef.current.handsFreeEnabled && liveStatusRef.current === 'idle') {
      pauseDictationTemporarily();
      window.setTimeout(() => armHandsFreeDictation(), 120);
    }
  };

  const handleToggleHandsFree = () => {
    if (!voiceSettings.handsFreeEnabled) {
      if (!isDictationSupported()) {
        showTransientVoiceNotice(
          language === 'hi'
            ? 'इस ब्राउज़र में SpeechRecognition उपलब्ध नहीं है'
            : 'SpeechRecognition is not supported in this browser'
        );
        return;
      }
      const next = { ...voiceSettings, handsFreeEnabled: true };
      voiceSettingsRef.current = next;
      setVoiceSettings(next);
      armHandsFreeDictation();
    } else {
      const next = { ...voiceSettings, handsFreeEnabled: false };
      voiceSettingsRef.current = next;
      setVoiceSettings(next);
      stopDictation();
      setInterimTranscript('');
    }
  };

  const handleToggleVoiceReply = () => {
    setVoiceSettings((prev) => {
      const nextEnabled = !prev.voiceReplyEnabled;
      if (!nextEnabled) {
        stopStudioSpeech();
      }
      return { ...prev, voiceReplyEnabled: nextEnabled };
    });
  };

  const handleChangePersona = (persona: VoicePersona) => {
    setVoiceSettings((prev) => ({ ...prev, persona }));
  };

  const handleChangeSpeed = (speed: VoiceSpeed) => {
    setVoiceSettings((prev) => ({ ...prev, speed }));
  };

  const handleToggleLiveVoice = () => {
    if (liveStatus !== 'idle') {
      stopLiveSession();
      if (voiceSettingsRef.current.handsFreeEnabled) {
        window.setTimeout(() => armHandsFreeDictation(), 180);
      }
      return;
    }

    stopStudioSpeech();
    pauseDictationTemporarily();
    setInterimTranscript('');

    startLiveSession({
      persona: voiceSettingsRef.current.persona,
      language: languageRef.current,
      onTranscript: (role, transcriptText) => {
        const trimmed = transcriptText.trim();
        if (!trimmed) return;
        setVedaMessages((prev) => {
          const last = prev[prev.length - 1];
          if (
            last &&
            last.role === role &&
            Date.now() - last.timestamp < 4000 &&
            last.id.startsWith('live_')
          ) {
            return [
              ...prev.slice(0, -1),
              { ...last, text: `${last.text} ${trimmed}`.trim(), timestamp: Date.now() },
            ];
          }
          return [
            ...prev,
            {
              id: `live_${role}_${Date.now().toString(36)}`,
              role,
              text: trimmed,
              timestamp: Date.now(),
            },
          ];
        });
      },
    });
  };

  const handleReplayMessage = useCallback(
    (message: VedaMessage) => {
      if (liveStatusRef.current !== 'idle') {
        stopLiveSession();
      }
      pauseDictationTemporarily();

      void speakWithStudioVoice(message.text, {
        persona: voiceSettingsRef.current.persona,
        speed: voiceSettingsRef.current.speed,
        language: languageRef.current,
        messageId: message.id,
      }).finally(() => {
        if (voiceSettingsRef.current.handsFreeEnabled && liveStatusRef.current === 'idle') {
          window.setTimeout(() => armHandsFreeDictation(), 350);
        }
      });
    },
    [armHandsFreeDictation]
  );

  const handleStopSpeech = useCallback(() => {
    stopStudioSpeech();
    if (voiceSettingsRef.current.handsFreeEnabled && liveStatusRef.current === 'idle') {
      window.setTimeout(() => armHandsFreeDictation(), 250);
    }
  }, [armHandsFreeDictation]);

  const handleUpdatePreviewState = useCallback(
    (
      department: DepartmentId,
      updater: (prev: DepartmentPreviewState) => DepartmentPreviewState
    ) => {
      setPreviewStates((prevAll) => {
        const updated = updater(prevAll[department]);
        if (updated.mode !== prevAll[department].mode) {
          studioBus.emit('preview:modeChange', { department, mode: updated.mode });
        }
        return {
          ...prevAll,
          [department]: updated,
        };
      });
    },
    []
  );

  const handleSelectProject = useCallback(
    (project: StudioProject) => {
      setActiveProjectIds((prev) => ({
        ...prev,
        [project.department]: project.id,
      }));
      setPreviewStates((prevAll) => ({
        ...prevAll,
        [project.department]: {
          ...prevAll[project.department],
          selectedFileId: project.files[0]?.id ?? null,
          revision: prevAll[project.department].revision + 1,
        },
      }));
      studioBus.emit('project:selected', { project });
      navigateRoom(project.department, 'project-select');
    },
    [navigateRoom]
  );

  // Part 4 Upgrade: Send Locked Step Plan to Department -> persists locked-plan.md AND auto-runs Coder build for Gaming/Apps!
  const handleSendPlanToDepartment = useCallback(
    async (plan: LockedStepPlan) => {
      const dept = plan.department;
      const markdown = formatLockedPlanMarkdown(plan);
      const existingId = activeProjectIdsRef.current[dept];
      const existing = existingId
        ? projectsRef.current.find((p) => p.id === existingId)
        : undefined;

      let targetProject: StudioProject;
      let planFileId: string;

      if (existing) {
        const existingPlanFile = existing.files.find((f) => f.path === 'locked-plan.md');
        if (existingPlanFile) {
          planFileId = existingPlanFile.id;
          targetProject = await saveProject({
            ...existing,
            files: existing.files.map((f) =>
              f.id === existingPlanFile.id
                ? { ...f, content: markdown, updatedAt: Date.now() }
                : f
            ),
          });
        } else {
          const newPlanFile = createNewProjectFile('locked-plan.md', markdown);
          planFileId = newPlanFile.id;
          targetProject = await saveProject({
            ...existing,
            files: [newPlanFile, ...existing.files],
          });
        }
      } else {
        const planFile = createNewProjectFile('locked-plan.md', markdown);
        planFileId = planFile.id;
        targetProject = await createProject({
          name: plan.title,
          department: dept,
          files: [planFile],
        });
      }

      handleProjectSaved(targetProject);
      setPreviewStates((prevAll) => ({
        ...prevAll,
        [dept]: {
          ...prevAll[dept],
          mode: 'expanded',
          selectedFileId: planFileId,
          revision: prevAll[dept].revision + 1,
        },
      }));
      switchToDepartmentViaBus(dept, 'locked-plan-send');

      if (dept === 'gaming' || dept === 'apps') {
        const firstStep = plan.steps[0];
        const buildPrompt = firstStep
          ? `Implement Step 1 (${firstStep.title}): ${firstStep.detail} for "${plan.title}".`
          : `Build Step 1 for "${plan.title}".`;
        setBuildStepByDept((prev) => ({ ...prev, [dept]: 1 }));

        await handleRunCoderStep({
          department: dept,
          prompt: buildPrompt,
          stepNumber: 1,
          overrideProject: targetProject,
          postDelegationToVeda: true,
        });
      }
    },
    [handleProjectSaved, handleRunCoderStep]
  );

  const activeDepartment: DepartmentId | null = activeRoom === 'veda' ? null : activeRoom;
  const activeDeptProject = activeDepartment
    ? projects.find((p) => p.id === activeProjectIds[activeDepartment]) ?? null
    : null;

  return (
    <div className="flex flex-col h-dvh w-full max-w-full overflow-hidden bg-[#0A0B0E] text-[#F4F5F7]">
      {/* Top Header (shrink-0, mobile-first 360px no-overflow) */}
      <header className="shrink-0 z-30 h-[52px] px-2.5 sm:px-4 studio-glass border-b border-white/8 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={() => navigateRoom('veda', 'brand')}
            className="flex items-center gap-2 min-w-0 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/70 rounded-lg"
          >
            <span
              aria-hidden="true"
              className="w-6 h-6 rounded-lg bg-amber-500 text-[#0A0B0E] font-bold text-xs flex items-center justify-center shrink-0"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              X
            </span>
            <span className="flex flex-col sm:flex-row sm:items-center sm:gap-2 min-w-0">
              <span
                className="text-[11px] sm:text-sm font-semibold tracking-tight leading-tight text-[#F4F5F7] whitespace-nowrap shrink-0"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {t.brand}
              </span>
              <span className="hidden sm:inline text-white/20 text-xs shrink-0" aria-hidden="true">
                /
              </span>
              <span
                className={`text-[10px] sm:text-xs font-medium leading-tight truncate ${
                  activeDepartment ? DEPARTMENT_META[activeDepartment].accentClass : 'text-amber-400'
                }`}
              >
                {ROOM_LABELS[activeRoom][language]}
              </span>
            </span>
          </button>
        </div>

        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <button
            type="button"
            onClick={handleToggleLanguage}
            aria-label="Toggle English or Hindi language"
            className="h-9 px-2 sm:px-2.5 rounded-xl bg-white/5 border border-white/10 text-[11px] font-semibold text-[#E5E8F0] hover:bg-white/10 transition-colors whitespace-nowrap shrink-0"
          >
            {language === 'en' ? 'EN/हिं' : 'हिं/EN'}
          </button>

          <button
            type="button"
            onClick={() => {
              setProjectsFilter(activeDepartment ?? 'all');
              setProjectsOpen(true);
            }}
            aria-label={t.projects}
            className="h-9 px-2 sm:px-3 rounded-xl bg-white/5 border border-white/10 text-xs font-medium text-[#E5E8F0] hover:bg-white/10 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <FolderOpen className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="hidden sm:inline">{t.projects}</span>
            <span className="font-mono text-[11px] text-[#9BA1AE] tabular-nums">
              {projects.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setAdminOpen(true)}
            aria-label="Open Admin and APK Builder"
            className="h-9 px-2 sm:px-2.5 rounded-xl bg-white/5 border border-white/10 text-xs font-medium text-[#E5E8F0] hover:bg-white/10 transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <Shield className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span className="hidden sm:inline">Admin</span>
          </button>

          <button
            type="button"
            onClick={() => setSecretsOpen(true)}
            aria-label="Open Secrets and Connections Vault"
            className="h-9 px-2 sm:px-3 rounded-xl bg-amber-500/14 border border-amber-500/35 text-xs font-semibold text-amber-300 hover:bg-amber-500/22 transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <KeyRound className="w-3.5 h-3.5 shrink-0" />
            <span>{t.secrets}</span>
            {configuredSecrets > 0 && (
              <span className="font-mono text-[10px] text-amber-200/80 tabular-nums hidden sm:inline">
                ({configuredSecrets})
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Main Active Room Container */}
      <main className="flex-1 min-h-0 overflow-hidden relative">
        {activeRoom === 'veda' ? (
          <VedaHub
            language={language}
            projects={projects}
            messages={vedaMessages}
            voiceSettings={voiceSettings}
            brainPreference={brainPreference}
            activeMemoryCount={activeMemoryCount}
            thinkingPhase={thinkingPhase}
            speakingMessageId={speakingMessageId}
            dictationStatus={dictationStatus}
            interimTranscript={interimTranscript}
            liveStatus={liveStatus}
            liveKeySlot={liveKeySlot}
            voiceNotice={voiceNotice}
            onDismissNotice={() => setVoiceNotice(null)}
            onSendMessage={handleSendVedaMessage}
            onSelectDepartment={(dept) => navigateRoom(dept, 'veda-card')}
            onOpenProjects={(filter) => {
              setProjectsFilter(filter ?? 'all');
              setProjectsOpen(true);
            }}
            onOpenSecrets={() => setSecretsOpen(true)}
            onOpenMemory={() => setMemoryOpen(true)}
            onChangeBrainPreference={setBrainPreference}
            onSendPlanToDepartment={handleSendPlanToDepartment}
            onApproveDelegatedBuild={(dept, nextStep) => handleApproveNextStep(dept, nextStep)}
            onReviseDelegatedBuild={handleReviseDelegatedBuild}
            prefillDraft={vedaPrefillDraft}
            onClearPrefillDraft={() => setVedaPrefillDraft(null)}
            onToggleHandsFree={handleToggleHandsFree}
            onToggleVoiceReply={handleToggleVoiceReply}
            onChangePersona={handleChangePersona}
            onChangeSpeed={handleChangeSpeed}
            onToggleLiveVoice={handleToggleLiveVoice}
            onReplayMessage={handleReplayMessage}
            onStopSpeech={handleStopSpeech}
          />
        ) : (
          <DepartmentRoom
            key={activeRoom}
            department={activeRoom}
            language={language}
            project={activeDeptProject}
            previewState={previewStates[activeRoom]}
            buildStepNumber={buildStepByDept[activeRoom]}
            isBuilding={isBuildingByDept[activeRoom]}
            buildStatusText={buildStatusByDept[activeRoom]}
            onUpdatePreviewState={handleUpdatePreviewState}
            onProjectSaved={handleProjectSaved}
            onOpenProjects={(dept) => {
              setProjectsFilter(dept);
              setProjectsOpen(true);
            }}
            onRunCoderStep={(params) => handleRunCoderStep(params)}
            onApproveNextStep={(dept) => handleApproveNextStep(dept)}
            onOpenSecrets={() => setSecretsOpen(true)}
            hasNewBhojpuriStory={hasNewBhojpuriStory}
            onClearNewBhojpuriStory={() => {
              markBhojpuriStoryRead();
              setHasNewBhojpuriStory(false);
            }}
            hasNewBhojpuriReel={hasNewBhojpuriReel}
            onClearNewBhojpuriReel={() => {
              setUnreadCloudReelFlag(false);
              setHasNewBhojpuriReel(false);
            }}
            pendingBhojpuriCommand={pendingBhojpuriCommand}
            onConsumeBhojpuriCommand={() => setPendingBhojpuriCommand(null)}
          />
        )}

        {/* Corner Header Badge when a fresh Cloud MP4 Reel or Scheduled Bhojpuri Story is ready */}
        {(hasNewBhojpuriReel || hasNewBhojpuriStory) && activeRoom !== 'bhojpuri' && (
          <button
            type="button"
            onClick={() => navigateRoom('bhojpuri', 'new-reel-badge')}
            className={`fixed top-[60px] right-3 z-40 h-8 px-3 rounded-full bg-[#151821]/95 shadow-lg text-[11px] font-semibold transition-colors inline-flex items-center gap-1.5 backdrop-blur-md ${
              hasNewBhojpuriReel
                ? 'border border-sky-400/60 text-sky-200 hover:bg-sky-500/20'
                : 'border border-amber-400/55 text-amber-200 hover:bg-amber-500/20'
            }`}
          >
            <span>
              {hasNewBhojpuriReel ? t.bhojpuriNewReelReady : t.bhojpuriNewStoryReady}
            </span>
          </button>
        )}
      </main>

      {/* Fixed Bottom Navigation Bar (shrink-0, z-30, locked inside flex-col h-dvh shell) */}
      <nav
        aria-label="Studio navigation"
        className="shrink-0 z-30 studio-glass border-t border-white/8 pb-safe"
      >
        <div className="w-full max-w-5xl mx-auto grid grid-cols-5 h-[58px]">
          {BOTTOM_TABS.map((tab) => {
            const isActive = activeRoom === tab.id;
            const showStoryDot =
              tab.id === 'bhojpuri' && (hasNewBhojpuriStory || hasNewBhojpuriReel) && !isActive;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => navigateRoom(tab.id, 'bottom-nav')}
                aria-current={isActive ? 'page' : undefined}
                className={`relative flex flex-col items-center justify-center gap-0.5 min-w-0 px-1 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-amber-400/70 ${
                  isActive ? 'text-amber-400' : 'text-[#8E95A5] hover:text-[#E5E8F0]'
                }`}
              >
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute top-0 inset-x-3 h-[2px] rounded-full bg-amber-400"
                  />
                )}
                <span className="relative text-[16px] leading-none" aria-hidden="true">
                  {tab.emoji}
                  {showStoryDot && (
                    <span className="absolute -top-0.5 -right-1.5 w-2 h-2 rounded-full bg-amber-400 ring-2 ring-[#0A0B0E]" />
                  )}
                </span>
                <span className="text-[10px] sm:text-[11px] font-medium leading-tight whitespace-nowrap truncate max-w-full">
                  {ROOM_LABELS[tab.id][language]}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Multi-Project IndexedDB Workspace Modal */}
      <ProjectsModal
        isOpen={projectsOpen}
        language={language}
        projects={projects}
        initialFilter={projectsFilter}
        onClose={() => setProjectsOpen(false)}
        onSelectProject={handleSelectProject}
        onProjectsMutated={refreshProjects}
      />

      {/* Self-Learning Permanent Memory Modal (z-[58]) */}
      <MemoryModal
        isOpen={memoryOpen}
        language={language}
        rules={memoryRules}
        onRulesChange={setMemoryRules}
        onClose={() => setMemoryOpen(false)}
      />

      {/* Admin, QR Code, .ZIP & 1-Click APK Exporter Modal (z-[60]) */}
      <AdminExportPanel
        isOpen={adminOpen}
        language={language}
        vault={vault}
        activeProject={activeDepartment ? activeProjects[activeDepartment] : null}
        onClose={() => setAdminOpen(false)}
        onOpenSecrets={() => setSecretsOpen(true)}
      />

      {/* Separate Non-Blocking Secrets & Connections Vault Modal (z-[60]) */}
      <SecretsPanel
        isOpen={secretsOpen}
        language={language}
        vault={vault}
        onVaultChange={setVault}
        onClose={() => setSecretsOpen(false)}
        onEnterVeda={() => {
          setSecretsOpen(false);
          navigateRoom('veda', 'secrets-enter-veda');
        }}
      />
    </div>
  );
}
