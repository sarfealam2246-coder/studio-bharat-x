import React, { useState } from 'react';
import {
  Activity,
  Bot,
  CheckCircle2,
  Cpu,
  Eye,
  Flame,
  FolderCode,
  Loader2,
  Maximize2,
  Minimize2,
  Newspaper,
  Smartphone,
  Sparkles,
  Sun,
  TrendingUp,
  Volume2,
} from 'lucide-react';
import { speakWithStudioVoice } from '../services/cloudTtsService';
import {
  AgentActionLog,
  AgentLiveBriefResult,
  executePhoneAgentAction,
  generateNativeFilesIntoAgentProject,
  loadPhoneAgentSettings,
  PhoneAgentSettings,
  runAgentLiveBrief,
  savePhoneAgentSettings,
  toggleNativeTopCapsule,
} from '../services/phoneAgentService';
import {
  DepartmentId,
  DepartmentPreviewState,
  Language,
  PreviewMode,
  StudioProject,
} from '../types/studio';

interface PhoneAgentRoomProps {
  language: Language;
  project: StudioProject | null;
  previewState: DepartmentPreviewState;
  onUpdatePreviewState: (
    department: DepartmentId,
    updater: (prev: DepartmentPreviewState) => DepartmentPreviewState
  ) => void;
  onProjectSaved: (project: StudioProject) => void;
}

export const PhoneAgentRoom: React.FC<PhoneAgentRoomProps> = ({
  language,
  project,
  previewState,
  onUpdatePreviewState,
  onProjectSaved,
}) => {
  const [settings, setSettings] = useState<PhoneAgentSettings>(() => loadPhoneAgentSettings());
  const [loadingBrief, setLoadingBrief] = useState<'news' | 'market' | 'youtube' | null>(null);
  const [brief, setBrief] = useState<AgentLiveBriefResult | null>(null);
  const [actionLogs, setActionLogs] = useState<AgentActionLog[]>([]);
  const [appToOpen, setAppToOpen] = useState('YouTube');
  const [generatingNative, setGeneratingNative] = useState(false);
  const [nativeNote, setNativeNote] = useState<string | null>(null);

  const setFoldMode = (mode: PreviewMode) => {
    onUpdatePreviewState('agent', (prev) => ({ ...prev, mode }));
  };

  const handleToggleSetting = async (
    key: 'topCapsuleEnabled' | 'backgroundVoiceEnabled' | 'screenReaderEnabled'
  ) => {
    const nextVal = !settings[key];
    const next: PhoneAgentSettings = { ...settings, [key]: nextVal };
    setSettings(next);
    savePhoneAgentSettings(next);

    if (key === 'topCapsuleEnabled') {
      const mode = await toggleNativeTopCapsule(nextVal);
      setActionLogs((prev) => [
        {
          id: `cap-${Date.now()}`,
          action: nextVal ? 'Top Capsule ON' : 'Top Capsule OFF',
          detail:
            mode === 'native'
              ? 'Updated Android SYSTEM_ALERT_WINDOW overlay.'
              : language === 'hi'
                ? `Top Capsule ${nextVal ? 'चालू' : 'बंद'} (APK में ऊपर तैरता रहेगा)`
                : `Top Capsule ${nextVal ? 'enabled' : 'disabled'} (floats on top in APK).`,
          mode,
          timestamp: Date.now(),
        },
        ...prev.slice(0, 7),
      ]);
    }
  };

  const handleRunBrief = async (topic: 'news' | 'market' | 'youtube') => {
    if (loadingBrief) return;
    setLoadingBrief(topic);
    try {
      const res = await runAgentLiveBrief(topic, language);
      setBrief(res);
      if (res.summary) {
        void speakWithStudioVoice(res.summary, { persona: 'Aoede', speed: 1.0 });
      }
    } finally {
      setLoadingBrief(null);
    }
  };

  const handleQuickAction = async (
    actionType: 'open_app' | 'swipe_up' | 'read_screen' | 'brightness',
    param?: string
  ) => {
    const log = await executePhoneAgentAction(actionType, language, param);
    setActionLogs((prev) => [log, ...prev.slice(0, 7)]);
  };

  const handleGenerateNative = async () => {
    setGeneratingNative(true);
    setNativeNote(null);
    try {
      const updated = await generateNativeFilesIntoAgentProject(project);
      onProjectSaved(updated);
      setNativeNote(
        language === 'hi'
          ? 'VedaAccessibilityService.kt और TopCapsuleService.kt प्रोजेक्ट में सेव हो गए!'
          : 'Saved VedaAccessibilityService.kt & TopCapsuleService.kt into project!'
      );
    } finally {
      setGeneratingNative(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto studio-scroll px-2.5 sm:px-4 py-2.5 space-y-2.5">
      {/* Foldable Agent Preview / Top Capsule Console */}
      <section className="rounded-2xl studio-glass border border-white/10 p-2.5 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-7 h-7 rounded-xl bg-sky-500/15 border border-sky-400/30 flex items-center justify-center text-sky-400 shrink-0">
              <Bot className="w-4 h-4" />
            </span>
            <div className="min-w-0">
              <h2 className="text-xs font-bold text-[#F4F5F7] truncate">
                {language === 'hi' ? 'फ़ोन एजेंट व लाइव न्यूज़ कंसोल' : 'Phone Agent & Live Console'}
              </h2>
              <p className="text-[10px] text-[#9BA1AE] truncate">
                {settings.topCapsuleEnabled ? '● Top Capsule Active' : 'No-Root Accessibility Bridge'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 bg-white/5 p-0.5 rounded-full border border-white/10 shrink-0">
            {(['expanded', 'compact', 'folded'] as PreviewMode[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setFoldMode(m)}
                className={`px-2 py-0.5 rounded-full text-[10px] font-semibold capitalize transition-colors ${
                  previewState.mode === m
                    ? 'bg-sky-500 text-[#0A0B0E]'
                    : 'text-[#9BA1AE] hover:text-white'
                }`}
              >
                {m === 'folded' ? 'Fold' : m}
              </button>
            ))}
          </div>
        </div>

        {previewState.mode !== 'folded' && (
          <div className="space-y-2">
            {/* Simulated Top Capsule Banner when ON */}
            {settings.topCapsuleEnabled && (
              <div className="flex items-center justify-center">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0A0B0E] border border-amber-400/50 shadow-lg text-[10.5px] font-bold text-amber-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>VEDA Capsule · Live Ready</span>
                </div>
              </div>
            )}

            {/* 1-Tap Live Research Cards */}
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => void handleRunBrief('news')}
                disabled={loadingBrief !== null}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex flex-col items-center gap-1 text-center transition-colors disabled:opacity-50"
              >
                {loadingBrief === 'news' ? (
                  <Loader2 className="w-4 h-4 text-sky-400 animate-spin" />
                ) : (
                  <Newspaper className="w-4 h-4 text-sky-400" />
                )}
                <span className="text-[10.5px] font-semibold text-[#F4F5F7]">
                  {language === 'hi' ? 'ताज़ा न्यूज़' : 'Latest News'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => void handleRunBrief('market')}
                disabled={loadingBrief !== null}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex flex-col items-center gap-1 text-center transition-colors disabled:opacity-50"
              >
                {loadingBrief === 'market' ? (
                  <Loader2 className="w-4 h-4 text-emerald-400 animate-spin" />
                ) : (
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                )}
                <span className="text-[10.5px] font-semibold text-[#F4F5F7]">
                  {language === 'hi' ? 'मार्केट' : 'Market'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => void handleRunBrief('youtube')}
                disabled={loadingBrief !== null}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex flex-col items-center gap-1 text-center transition-colors disabled:opacity-50"
              >
                {loadingBrief === 'youtube' ? (
                  <Loader2 className="w-4 h-4 text-rose-400 animate-spin" />
                ) : (
                  <Flame className="w-4 h-4 text-rose-400" />
                )}
                <span className="text-[10.5px] font-semibold text-[#F4F5F7]">
                  {language === 'hi' ? 'YT ट्रेंड्स' : 'YT Trends'}
                </span>
              </button>
            </div>

            {/* Live Brief Output */}
            {brief && (
              <div className="rounded-xl bg-white/5 border border-sky-400/25 p-2.5 space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-bold text-sky-300">{brief.topicLabel}</span>
                  <button
                    type="button"
                    onClick={() => void speakWithStudioVoice(brief.summary, { persona: 'Aoede', speed: 1.0 })}
                    className="px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 text-[10px] font-semibold inline-flex items-center gap-1"
                  >
                    <Volume2 className="w-3 h-3" />
                    <span>{language === 'hi' ? 'सुनें' : 'Listen'}</span>
                  </button>
                </div>
                <p className="text-[11.5px] leading-relaxed text-[#E5E8F0] whitespace-pre-wrap">
                  {brief.summary}
                </p>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Top Capsule & No-Root Accessibility Controls */}
      <section className="rounded-2xl studio-glass border border-white/10 p-3 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-[#F4F5F7] flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'hi' ? 'मोबाइल कंट्रोल व कैप्सूल' : 'Mobile Controls & Capsule'}</span>
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-semibold">
            No-Root Ready
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5">
          {[
            {
              key: 'topCapsuleEnabled' as const,
              label: language === 'hi' ? 'Top कैप्सूल' : 'Top Capsule',
              icon: Sparkles,
            },
            {
              key: 'backgroundVoiceEnabled' as const,
              label: language === 'hi' ? 'बैकग्राउंड वॉइस' : 'Background Voice',
              icon: Activity,
            },
            {
              key: 'screenReaderEnabled' as const,
              label: language === 'hi' ? 'स्क्रीन रीडर' : 'Screen Reader',
              icon: Eye,
            },
          ].map((item) => {
            const Icon = item.icon;
            const active = settings[item.key];
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => void handleToggleSetting(item.key)}
                className={`p-2 rounded-xl border text-left flex items-center justify-between gap-2 transition-colors ${
                  active
                    ? 'bg-amber-500/15 border-amber-400/40 text-amber-200'
                    : 'bg-white/5 border-white/10 text-[#9BA1AE]'
                }`}
              >
                <span className="text-[11px] font-semibold flex items-center gap-1.5 truncate">
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </span>
                <span className="text-[10px] font-bold">{active ? 'ON' : 'OFF'}</span>
              </button>
            );
          })}
        </div>

        {/* Quick Phone Automation Actions */}
        <div className="flex items-center gap-1.5">
          <input
            type="text"
            value={appToOpen}
            onChange={(e) => setAppToOpen(e.target.value)}
            placeholder="App name (e.g. YouTube)"
            className="flex-1 min-w-0 h-9 px-2.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white focus:outline-none focus:border-sky-400"
          />
          <button
            type="button"
            onClick={() => void handleQuickAction('open_app', appToOpen)}
            className="h-9 px-3 rounded-xl bg-sky-500 text-[#0A0B0E] text-xs font-bold shrink-0"
          >
            {language === 'hi' ? 'ऐप खोलें' : 'Open App'}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-1.5">
          <button
            type="button"
            onClick={() => void handleQuickAction('swipe_up')}
            className="h-9 px-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] font-semibold text-[#E5E8F0] inline-flex items-center justify-center gap-1"
          >
            <Maximize2 className="w-3 h-3 text-sky-400" />
            <span>{language === 'hi' ? 'स्वाइप अप' : 'Swipe Up'}</span>
          </button>
          <button
            type="button"
            onClick={() => void handleQuickAction('read_screen')}
            className="h-9 px-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] font-semibold text-[#E5E8F0] inline-flex items-center justify-center gap-1"
          >
            <Eye className="w-3 h-3 text-emerald-400" />
            <span>{language === 'hi' ? 'स्क्रीन पढ़ें' : 'Read Screen'}</span>
          </button>
          <button
            type="button"
            onClick={() => void handleQuickAction('brightness', '90')}
            className="h-9 px-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] font-semibold text-[#E5E8F0] inline-flex items-center justify-center gap-1"
          >
            <Sun className="w-3 h-3 text-amber-400" />
            <span>{language === 'hi' ? 'ब्राइटनेस' : 'Brightness'}</span>
          </button>
        </div>

        {/* Generate Kotlin Native Accessibility + Capsule Files */}
        <button
          type="button"
          onClick={() => void handleGenerateNative()}
          disabled={generatingNative}
          className="w-full h-9 rounded-xl bg-white/8 hover:bg-white/12 border border-white/15 text-xs font-semibold text-amber-300 inline-flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
        >
          {generatingNative ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <FolderCode className="w-3.5 h-3.5" />
          )}
          <span>
            {language === 'hi'
              ? 'Android Native Kotlin फाइलें (Capsule + Accessibility) बनाएँ'
              : 'Generate Android Native Files (Capsule + Accessibility)'}
          </span>
        </button>

        {nativeNote && (
          <div className="rounded-xl bg-emerald-500/12 border border-emerald-500/30 px-2.5 py-1.5 text-[11px] text-emerald-300 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            <span>{nativeNote}</span>
          </div>
        )}

        {actionLogs.length > 0 && (
          <div className="space-y-1 pt-1">
            {actionLogs.slice(0, 4).map((log) => (
              <div
                key={log.id}
                className="rounded-lg bg-white/4 border border-white/8 px-2.5 py-1.5 text-[10.5px] flex items-start justify-between gap-2"
              >
                <div className="min-w-0">
                  <span className="font-bold text-sky-300">{log.action}: </span>
                  <span className="text-[#CBD5E1]">{log.detail}</span>
                </div>
                <span className="text-[9px] font-mono text-[#9BA1AE] shrink-0 uppercase">
                  {log.mode}
                </span>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
