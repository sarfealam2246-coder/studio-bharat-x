import React, { useMemo, useState } from 'react';
import {
  Archive,
  CheckCircle2,
  ExternalLink,
  Loader2,
  Lock,
  QrCode,
  Rocket,
  Shield,
  X,
} from 'lucide-react';
import {
  buildApkWorkflowYaml,
  buildDeterministicQrMatrix,
  buildPinLockedAdminHtml,
  computePreFlightStatus,
  pushProjectAndApkToGitHub,
} from '../services/githubExportService';
import { downloadProjectZip, ZipFileEntry } from '../services/zipExportService';
import { Language, SecretsVaultState, StudioProject } from '../types/studio';

interface AdminExportPanelProps {
  isOpen: boolean;
  language: Language;
  vault: SecretsVaultState;
  activeProject: StudioProject | null;
  onClose: () => void;
  onOpenSecrets: () => void;
}

export const AdminExportPanel: React.FC<AdminExportPanelProps> = ({
  isOpen,
  language,
  vault,
  activeProject,
  onClose,
  onOpenSecrets,
}) => {
  const [appName, setAppName] = useState('STUDIO BHARAT X');
  const [ownerPin, setOwnerPin] = useState('2468');
  const [githubOwner, setGithubOwner] = useState('sarfealam2246-coder');
  const [githubRepo, setGithubRepo] = useState('studio-bharat-x');
  const [pushing, setPushing] = useState(false);
  const [pushNote, setPushNote] = useState<{ ok: boolean; text: string; url?: string } | null>(null);

  const preflight = useMemo(() => computePreFlightStatus(vault), [vault]);
  const releaseUrl = `https://github.com/${githubOwner.trim() || 'sarfealam2246-coder'}/${
    githubRepo.trim() || 'studio-bharat-x'
  }/actions`;
  const qrMatrix = useMemo(() => buildDeterministicQrMatrix(releaseUrl, 21), [releaseUrl]);

  if (!isOpen) return null;

  const handleDownloadZip = () => {
    const entries: ZipFileEntry[] = [
      { path: '.github/workflows/build-apk.yml', content: buildApkWorkflowYaml(appName) },
      {
        path: 'docs/admin.html',
        content: buildPinLockedAdminHtml(
          appName,
          ownerPin,
          `https://github.com/${githubOwner}/${githubRepo}`
        ),
      },
    ];
    if (activeProject) {
      for (const f of activeProject.files) {
        entries.push({ path: f.path.replace(/^\/+/, ''), content: f.content });
      }
    }
    const slug = (activeProject?.name || appName).toLowerCase().replace(/[^a-z0-9]+/g, '-');
    downloadProjectZip(`${slug}.zip`, entries);
  };

  const handleBuildAndPush = async () => {
    setPushing(true);
    setPushNote(null);
    try {
      const res = await pushProjectAndApkToGitHub({
        githubPat: vault.platformTokens.githubPat,
        owner: githubOwner,
        repo: githubRepo,
        appName,
        ownerPin,
        project: activeProject,
      });
      setPushNote({
        ok: res.ok,
        text: res.message,
        url: res.actionsUrl,
      });
    } finally {
      setPushing(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-md flex items-end sm:items-center justify-center p-2 pb-8"
      role="dialog"
      aria-modal="true"
      aria-label="Admin & APK Release Panel"
    >
      <div className="w-full max-w-md max-h-[88dvh] overflow-y-auto studio-scroll rounded-3xl bg-[#11131A] border border-white/15 p-4 space-y-3 text-[#F4F5F7] shadow-2xl">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
              <Shield className="w-4 h-4" />
            </span>
            <div>
              <h2 className="text-sm font-bold">
                {language === 'hi' ? 'एडमिन व APK बिल्डर' : 'Admin, QR & APK Exporter'}
              </h2>
              <p className="text-[10.5px] text-[#9BA1AE]">1-Commit GitHub APK + PIN + ZIP</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Admin Panel"
            className="w-8 h-8 rounded-full bg-white/8 hover:bg-white/15 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Pre-Flight Readiness Chips */}
        <div className="rounded-2xl bg-white/5 border border-white/10 p-2.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-[#E5E8F0]">
              {language === 'hi' ? 'Pre-Flight जाँच' : 'Pre-Flight Readiness'}
            </span>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenSecrets();
              }}
              className="text-[10.5px] font-semibold text-amber-300 underline"
            >
              {language === 'hi' ? 'Secrets खोलें' : 'Open Secrets'}
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5 text-[10px] font-semibold">
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
              Gemini ({preflight.geminiCount}/3)
            </span>
            <span className="px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-300 border border-sky-500/30">
              Other AI ({preflight.otherAiCount})
            </span>
            <span
              className={`px-2 py-0.5 rounded-full border ${
                preflight.hasGithubPat
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
              }`}
            >
              GitHub PAT {preflight.hasGithubPat ? '✓' : '(Optional for ZIP)'}
            </span>
            <span
              className={`px-2 py-0.5 rounded-full border ${
                preflight.hasFacebookToken
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : 'bg-white/8 text-[#9BA1AE] border-white/15'
              }`}
            >
              Facebook {preflight.hasFacebookToken ? '✓' : 'Optional'}
            </span>
          </div>
        </div>

        {/* App Name, Owner PIN, GitHub Target */}
        <div className="space-y-2 text-xs">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-[#9BA1AE]">App Name</label>
              <input
                type="text"
                value={appName}
                onChange={(e) => setAppName(e.target.value)}
                className="w-full h-9 px-2.5 rounded-xl bg-white/5 border border-white/12 text-white mt-0.5"
              />
            </div>
            <div>
              <label className="text-[10px] text-[#9BA1AE] flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" /> Owner PIN
              </label>
              <input
                type="password"
                value={ownerPin}
                onChange={(e) => setOwnerPin(e.target.value)}
                className="w-full h-9 px-2.5 rounded-xl bg-white/5 border border-white/12 text-white mt-0.5"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-[#9BA1AE]">GitHub Owner</label>
              <input
                type="text"
                value={githubOwner}
                onChange={(e) => setGithubOwner(e.target.value)}
                className="w-full h-9 px-2.5 rounded-xl bg-white/5 border border-white/12 text-white mt-0.5"
              />
            </div>
            <div>
              <label className="text-[10px] text-[#9BA1AE]">GitHub Repo</label>
              <input
                type="text"
                value={githubRepo}
                onChange={(e) => setGithubRepo(e.target.value)}
                className="w-full h-9 px-2.5 rounded-xl bg-white/5 border border-white/12 text-white mt-0.5"
              />
            </div>
          </div>
        </div>

        {/* Live QR Code Preview */}
        <div className="rounded-2xl bg-white/5 border border-white/10 p-3 flex items-center gap-3">
          <div className="bg-white p-1.5 rounded-xl shrink-0">
            <svg width="72" height="72" viewBox="0 0 21 21" aria-label="APK Release QR Code">
              {qrMatrix.map((row, r) =>
                row.map((cell, c) =>
                  cell ? <rect key={`${r}-${c}`} x={c} y={r} width="1" height="1" fill="#0A0B0E" /> : null
                )
              )}
            </svg>
          </div>
          <div className="min-w-0 flex-1 space-y-1">
            <div className="text-xs font-bold flex items-center gap-1 text-amber-300">
              <QrCode className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'APK रिलीज QR कोड' : 'APK Release QR Code'}</span>
            </div>
            <p className="text-[10px] text-[#9BA1AE] break-all">{releaseUrl}</p>
          </div>
        </div>

        {/* Export Actions */}
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={handleDownloadZip}
            className="h-10 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-bold inline-flex items-center justify-center gap-1.5"
          >
            <Archive className="w-3.5 h-3.5 text-sky-400" />
            <span>Download .ZIP</span>
          </button>

          <button
            type="button"
            onClick={() => void handleBuildAndPush()}
            disabled={pushing}
            className="h-10 rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0A0B0E] text-xs font-bold inline-flex items-center justify-center gap-1.5 disabled:opacity-50"
          >
            {pushing ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Rocket className="w-3.5 h-3.5" />
            )}
            <span>Build &amp; Push APK</span>
          </button>
        </div>

        {pushNote && (
          <div
            className={`rounded-xl p-2.5 text-[11px] border flex items-start justify-between gap-2 ${
              pushNote.ok
                ? 'bg-emerald-500/15 border-emerald-500/35 text-emerald-200'
                : 'bg-rose-500/15 border-rose-500/35 text-rose-200'
            }`}
          >
            <span className="flex items-start gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span>{pushNote.text}</span>
            </span>
            {pushNote.url && (
              <a
                href={pushNote.url}
                target="_blank"
                rel="noreferrer"
                className="text-sky-300 shrink-0 inline-flex items-center gap-0.5 underline"
              >
                <span>Open</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
