import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Eye,
  EyeOff,
  KeyRound,
  Loader2,
  Plus,
  RefreshCw,
  ShieldCheck,
  Trash2,
  X,
  AlertCircle,
} from 'lucide-react';
import { UI_COPY } from '../i18n/translations';
import {
  countConfiguredSecrets,
  OTHER_AI_PROVIDERS,
  saveSecretsVault,
  testAllSecrets,
} from '../services/secretsService';
import {
  Language,
  OtherAiKeyEntry,
  OtherAiProvider,
  ReservedTokenEntry,
  SecretCheckResult,
  SecretsVaultState,
} from '../types/studio';

interface SecretsPanelProps {
  isOpen: boolean;
  language: Language;
  vault: SecretsVaultState;
  onVaultChange: (next: SecretsVaultState) => void;
  onClose: () => void;
  onEnterVeda: () => void;
}

function createSlotId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
}

function StatusIndicator({ result }: { result?: SecretCheckResult }) {
  if (!result || result.status === 'idle') return null;

  if (result.status === 'testing') {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-300 whitespace-nowrap shrink-0">
        <Loader2 className="w-3.5 h-3.5 animate-spin" />
        Testing
      </span>
    );
  }

  if (result.status === 'active') {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-400 whitespace-nowrap shrink-0">
        <CheckCircle2 className="w-3.5 h-3.5" />
        Active ✓
        {result.detail ? (
          <span className="text-emerald-300/80 font-normal hidden sm:inline">· {result.detail}</span>
        ) : null}
        {typeof result.latencyMs === 'number' ? (
          <span className="font-mono text-[11px] text-emerald-300/70 tabular-nums hidden sm:inline">
            {result.latencyMs}ms
          </span>
        ) : null}
      </span>
    );
  }

  return (
    <span
      className="inline-flex items-center gap-1 text-xs font-medium text-rose-400 whitespace-nowrap shrink-0"
      title={result.detail || 'Error'}
    >
      <AlertCircle className="w-3.5 h-3.5" />
      Error{result.detail ? `: ${result.detail}` : ''}
    </span>
  );
}

export const SecretsPanel: React.FC<SecretsPanelProps> = ({
  isOpen,
  language,
  vault,
  onVaultChange,
  onClose,
  onEnterVeda,
}) => {
  const t = UI_COPY[language];
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [checkResults, setCheckResults] = useState<Record<string, SecretCheckResult>>({});
  const [isTesting, setIsTesting] = useState(false);

  // Section B: "+ Add AI Key" form state
  const [showAddAiForm, setShowAddAiForm] = useState(false);
  const [newProvider, setNewProvider] = useState<OtherAiProvider>('groq');
  const [newEndpoint, setNewEndpoint] = useState(OTHER_AI_PROVIDERS[0].defaultEndpoint);
  const [newModel, setNewModel] = useState(OTHER_AI_PROVIDERS[0].defaultModels[0]);
  const [newApiKey, setNewApiKey] = useState('');
  const [newLabel, setNewLabel] = useState('');
  const [showNewApiKey, setShowNewApiKey] = useState(false);

  // Section C: "+ Add Reserved Token" form state
  const [showAddReservedForm, setShowAddReservedForm] = useState(false);
  const [reservedName, setReservedName] = useState('');
  const [reservedValue, setReservedValue] = useState('');
  const [showReservedValue, setShowReservedValue] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  const activeProviderPreset = useMemo(
    () => OTHER_AI_PROVIDERS.find((p) => p.id === newProvider) ?? OTHER_AI_PROVIDERS[0],
    [newProvider]
  );

  const summary = useMemo(() => {
    const entries = Object.values(checkResults);
    const active = entries.filter((r) => r.status === 'active').length;
    const errors = entries.filter((r) => r.status === 'error').length;
    return { total: entries.length, active, errors };
  }, [checkResults]);

  const configuredCount = useMemo(() => countConfiguredSecrets(vault), [vault]);

  if (!isOpen) return null;

  const commitVault = (next: SecretsVaultState) => {
    const saved = saveSecretsVault(next);
    onVaultChange(saved);
  };

  const toggleReveal = (key: string) => {
    setRevealed((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleGeminiChange = (index: 0 | 1 | 2, value: string) => {
    const nextKeys: [string, string, string] = [...vault.geminiKeys];
    nextKeys[index] = value;
    commitVault({ ...vault, geminiKeys: nextKeys });
    setCheckResults((prev) => {
      const copy = { ...prev };
      delete copy[`gemini_${index + 1}`];
      return copy;
    });
  };

  const handleProviderSelect = (providerId: OtherAiProvider) => {
    setNewProvider(providerId);
    const preset = OTHER_AI_PROVIDERS.find((p) => p.id === providerId);
    if (preset) {
      setNewEndpoint(preset.defaultEndpoint);
      setNewModel(preset.defaultModels[0] ?? '');
    }
  };

  const handleAddOtherAiKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newApiKey.trim()) return;
    const entry: OtherAiKeyEntry = {
      id: createSlotId('ai'),
      provider: newProvider,
      endpoint: newEndpoint.trim() || activeProviderPreset.defaultEndpoint,
      model: newModel.trim() || activeProviderPreset.defaultModels[0] || 'default',
      apiKey: newApiKey.trim(),
      label: newLabel.trim(),
    };
    commitVault({
      ...vault,
      otherAiKeys: [...vault.otherAiKeys, entry],
    });
    setNewApiKey('');
    setNewLabel('');
    setShowNewApiKey(false);
    setShowAddAiForm(false);
  };

  const handleRemoveOtherAiKey = (id: string) => {
    commitVault({
      ...vault,
      otherAiKeys: vault.otherAiKeys.filter((item) => item.id !== id),
    });
    setCheckResults((prev) => {
      const copy = { ...prev };
      delete copy[`other:${id}`];
      return copy;
    });
  };

  const handlePlatformChange = (
    field: 'githubPat' | 'facebookPageId' | 'facebookPageAccessToken',
    value: string
  ) => {
    commitVault({
      ...vault,
      platformTokens: {
        ...vault.platformTokens,
        [field]: value,
      },
    });
    setCheckResults((prev) => {
      const copy = { ...prev };
      delete copy[field === 'githubPat' ? 'platform:github' : 'platform:facebook'];
      return copy;
    });
  };

  const handleAddReservedToken = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reservedName.trim() || !reservedValue.trim()) return;
    const entry: ReservedTokenEntry = {
      id: createSlotId('res'),
      name: reservedName.trim(),
      value: reservedValue.trim(),
    };
    commitVault({
      ...vault,
      reservedTokens: [...vault.reservedTokens, entry],
    });
    setReservedName('');
    setReservedValue('');
    setShowReservedValue(false);
    setShowAddReservedForm(false);
  };

  const handleRemoveReservedToken = (id: string) => {
    commitVault({
      ...vault,
      reservedTokens: vault.reservedTokens.filter((item) => item.id !== id),
    });
    setCheckResults((prev) => {
      const copy = { ...prev };
      delete copy[`reserved:${id}`];
      return copy;
    });
  };

  const handleTestAndConnectAll = async () => {
    saveSecretsVault(vault);
    const pending: Record<string, SecretCheckResult> = {};
    vault.geminiKeys.forEach((key, idx) => {
      if (key.trim()) {
        pending[`gemini_${idx + 1}`] = { slotId: `gemini_${idx + 1}`, status: 'testing' };
      }
    });
    vault.otherAiKeys.forEach((entry) => {
      if (entry.apiKey.trim()) {
        pending[`other:${entry.id}`] = { slotId: `other:${entry.id}`, status: 'testing' };
      }
    });
    if (vault.platformTokens.githubPat.trim()) {
      pending['platform:github'] = { slotId: 'platform:github', status: 'testing' };
    }
    if (
      vault.platformTokens.facebookPageAccessToken.trim() ||
      vault.platformTokens.facebookPageId.trim()
    ) {
      pending['platform:facebook'] = { slotId: 'platform:facebook', status: 'testing' };
    }
    vault.reservedTokens.forEach((res) => {
      if (res.name.trim() && res.value.trim()) {
        pending[`reserved:${res.id}`] = { slotId: `reserved:${res.id}`, status: 'testing' };
      }
    });

    setCheckResults(pending);
    if (Object.keys(pending).length === 0) {
      return;
    }

    setIsTesting(true);
    try {
      const results = await testAllSecrets(vault);
      setCheckResults(results);
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="secrets-vault-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-2xl max-h-[92dvh] flex flex-col rounded-t-2xl sm:rounded-2xl bg-[#111319] border border-white/10 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="shrink-0 flex items-center justify-between gap-3 px-4 py-3.5 border-b border-white/8 bg-[#141720]">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-amber-400 shrink-0" />
              <h2
                id="secrets-vault-title"
                className="text-base font-semibold text-[#F4F5F7] truncate"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {t.secretsTitle}
              </h2>
            </div>
            <p className="text-xs text-[#9BA1AE] mt-0.5 leading-snug">{t.secretsSubtitle}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close secrets modal"
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-[#9BA1AE] hover:text-white hover:bg-white/6 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll px-4 py-4 space-y-6">
          {/* Section A — Gemini (3-Key Personal Load-Balancer) */}
          <section className="space-y-3">
            <div>
              <h3
                className="text-sm font-semibold text-[#F4F5F7]"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {t.sectionA}
              </h3>
              <p className="text-xs text-[#9BA1AE] mt-0.5">{t.sectionADesc}</p>
            </div>

            <div className="space-y-2.5">
              {([0, 1, 2] as const).map((idx) => {
                const slotId = `gemini_${idx + 1}`;
                const isShown = Boolean(revealed[slotId]);
                const val = vault.geminiKeys[idx];
                return (
                  <div key={slotId} className="space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <label htmlFor={slotId} className="text-xs font-medium text-[#D1D5DF]">
                        Gemini Key {idx + 1}
                      </label>
                      <StatusIndicator result={checkResults[slotId]} />
                    </div>
                    <div className="flex items-center gap-1.5">
                      <input
                        id={slotId}
                        type={isShown ? 'text' : 'password'}
                        value={val}
                        onChange={(e) => handleGeminiChange(idx, e.target.value)}
                        placeholder={`AIza... (Optional Slot ${idx + 1})`}
                        autoComplete="off"
                        spellCheck={false}
                        className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70 transition-colors"
                      />
                      <button
                        type="button"
                        onClick={() => toggleReveal(slotId)}
                        aria-label={isShown ? `Hide Gemini Key ${idx + 1}` : `Show Gemini Key ${idx + 1}`}
                        className="h-10 w-10 shrink-0 flex items-center justify-center rounded-xl bg-[#181B24] border border-white/8 text-[#9BA1AE] hover:text-white transition-colors"
                      >
                        {isShown ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <hr className="border-white/8" />

          {/* Section B — Other AI Models (Generic Picker) */}
          <section className="space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h3
                  className="text-sm font-semibold text-[#F4F5F7]"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  {t.sectionB}
                </h3>
                <p className="text-xs text-[#9BA1AE] mt-0.5">{t.sectionBDesc}</p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddAiForm((prev) => !prev)}
                className="shrink-0 h-9 px-3 rounded-xl bg-amber-500/14 border border-amber-500/30 text-amber-300 text-xs font-medium hover:bg-amber-500/22 transition-colors whitespace-nowrap"
              >
                {showAddAiForm ? t.cancel : t.addAiKey}
              </button>
            </div>

            {showAddAiForm && (
              <form
                onSubmit={handleAddOtherAiKey}
                className="p-3.5 rounded-xl bg-[#161922] border border-white/10 space-y-3"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-[#D1D5DF]" htmlFor="other-provider">
                      Endpoint / Provider
                    </label>
                    <select
                      id="other-provider"
                      value={newProvider}
                      onChange={(e) => handleProviderSelect(e.target.value as OtherAiProvider)}
                      className="w-full h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs text-[#F4F5F7] focus:outline-none focus:border-amber-400/70"
                    >
                      {OTHER_AI_PROVIDERS.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-medium text-[#D1D5DF]" htmlFor="other-model">
                      Model
                    </label>
                    <input
                      id="other-model"
                      list="provider-models-list"
                      type="text"
                      value={newModel}
                      onChange={(e) => setNewModel(e.target.value)}
                      placeholder="Select or type model ID"
                      className="w-full h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                    />
                    <datalist id="provider-models-list">
                      {activeProviderPreset.defaultModels.map((model) => (
                        <option key={model} value={model} />
                      ))}
                    </datalist>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-[#D1D5DF]" htmlFor="other-endpoint">
                    Base Endpoint URL
                  </label>
                  <input
                    id="other-endpoint"
                    type="url"
                    value={newEndpoint}
                    onChange={(e) => setNewEndpoint(e.target.value)}
                    placeholder="https://api.provider.com/v1"
                    className="w-full h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div className="space-y-1">
                    <label className="text-xs font-medium text-[#D1D5DF]" htmlFor="other-api-key">
                      API Key
                    </label>
                    <div className="flex items-center gap-1.5">
                      <input
                        id="other-api-key"
                        type={showNewApiKey ? 'text' : 'password'}
                        value={newApiKey}
                        onChange={(e) => setNewApiKey(e.target.value)}
                        placeholder="sk-..."
                        autoComplete="off"
                        spellCheck={false}
                        required
                        className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewApiKey((s) => !s)}
                        aria-label="Toggle API key visibility"
                        className="h-10 w-10 shrink-0 flex items-center justify-center rounded-xl bg-[#0A0B0E] border border-white/10 text-[#9BA1AE] hover:text-white"
                      >
                        {showNewApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-medium text-[#D1D5DF]" htmlFor="other-label">
                      Label (Optional)
                    </label>
                    <input
                      id="other-label"
                      type="text"
                      value={newLabel}
                      onChange={(e) => setNewLabel(e.target.value)}
                      placeholder="e.g. Fast Coder"
                      className="w-full h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowAddAiForm(false)}
                    className="h-9 px-3.5 rounded-xl text-xs font-medium text-[#9BA1AE] hover:text-white hover:bg-white/6 transition-colors"
                  >
                    {t.cancel}
                  </button>
                  <button
                    type="submit"
                    className="h-9 px-4 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 transition-colors inline-flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Save Key
                  </button>
                </div>
              </form>
            )}

            {vault.otherAiKeys.length === 0 ? (
              <p className="text-xs text-[#737A8A] py-1">
                No external AI keys added yet. Click &ldquo;{t.addAiKey}&rdquo; whenever needed.
              </p>
            ) : (
              <div className="divide-y divide-white/8 border border-white/8 rounded-xl bg-[#0E1016] overflow-hidden">
                {vault.otherAiKeys.map((entry) => {
                  const providerLabel =
                    OTHER_AI_PROVIDERS.find((p) => p.id === entry.provider)?.label ?? entry.provider;
                  const slotId = `other:${entry.id}`;
                  const isShown = Boolean(revealed[slotId]);
                  return (
                    <div
                      key={entry.id}
                      className="p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                    >
                      <div className="min-w-0 space-y-0.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-semibold text-[#F4F5F7]">
                            {entry.label || providerLabel}
                          </span>
                          <span className="text-xs text-[#7F8696]">·</span>
                          <span className="text-xs text-[#9BA1AE]">{providerLabel}</span>
                          <span className="text-xs text-[#7F8696]">·</span>
                          <span className="text-xs font-mono text-[#B7BDC9] truncate max-w-[180px]">
                            {entry.model}
                          </span>
                        </div>
                        <div className="text-[11px] font-mono text-[#737A8A] truncate">
                          {isShown ? entry.apiKey : '••••••••••••••••'}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                        <StatusIndicator result={checkResults[slotId]} />
                        <button
                          type="button"
                          onClick={() => toggleReveal(slotId)}
                          aria-label="Toggle key reveal"
                          className="h-8 w-8 flex items-center justify-center rounded-lg text-[#9BA1AE] hover:text-white hover:bg-white/6"
                        >
                          {isShown ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRemoveOtherAiKey(entry.id)}
                          aria-label="Delete AI key"
                          className="h-8 w-8 flex items-center justify-center rounded-lg text-[#9BA1AE] hover:text-rose-400 hover:bg-rose-500/10"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          <hr className="border-white/8" />

          {/* Section C — Platform & Reserved Future Tokens */}
          <section className="space-y-3">
            <div>
              <h3
                className="text-sm font-semibold text-[#F4F5F7]"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {t.sectionC}
              </h3>
              <p className="text-xs text-[#9BA1AE] mt-0.5">{t.sectionCDesc}</p>
            </div>

            {/* GitHub PAT */}
            <div className="space-y-1">
              <div className="flex items-center justify-between gap-2">
                <label htmlFor="github-pat" className="text-xs font-medium text-[#D1D5DF]">
                  GitHub PAT
                </label>
                <StatusIndicator result={checkResults['platform:github']} />
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  id="github-pat"
                  type={revealed['platform:github'] ? 'text' : 'password'}
                  value={vault.platformTokens.githubPat}
                  onChange={(e) => handlePlatformChange('githubPat', e.target.value)}
                  placeholder="ghp_... / github_pat_... (Optional)"
                  autoComplete="off"
                  spellCheck={false}
                  className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                />
                <button
                  type="button"
                  onClick={() => toggleReveal('platform:github')}
                  aria-label="Toggle GitHub PAT visibility"
                  className="h-10 w-10 shrink-0 flex items-center justify-center rounded-xl bg-[#181B24] border border-white/8 text-[#9BA1AE] hover:text-white"
                >
                  {revealed['platform:github'] ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Facebook Page ID & Page Access Token */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label htmlFor="fb-page-id" className="text-xs font-medium text-[#D1D5DF]">
                  Facebook Page ID
                </label>
                <input
                  id="fb-page-id"
                  type="text"
                  value={vault.platformTokens.facebookPageId}
                  onChange={(e) => handlePlatformChange('facebookPageId', e.target.value)}
                  placeholder="e.g. 1029384756123 (Optional)"
                  autoComplete="off"
                  spellCheck={false}
                  className="w-full h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                />
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <label htmlFor="fb-page-token" className="text-xs font-medium text-[#D1D5DF]">
                    Facebook Page Access Token
                  </label>
                  <StatusIndicator result={checkResults['platform:facebook']} />
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    id="fb-page-token"
                    type={revealed['platform:facebook'] ? 'text' : 'password'}
                    value={vault.platformTokens.facebookPageAccessToken}
                    onChange={(e) => handlePlatformChange('facebookPageAccessToken', e.target.value)}
                    placeholder="EAAG... (Optional)"
                    autoComplete="off"
                    spellCheck={false}
                    className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                  />
                  <button
                    type="button"
                    onClick={() => toggleReveal('platform:facebook')}
                    aria-label="Toggle Facebook Page Token visibility"
                    className="h-10 w-10 shrink-0 flex items-center justify-center rounded-xl bg-[#181B24] border border-white/8 text-[#9BA1AE] hover:text-white"
                  >
                    {revealed['platform:facebook'] ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Reserved Future Tokens */}
            <div className="pt-1 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-medium text-[#D1D5DF]">Reserved Future Tokens</span>
                <button
                  type="button"
                  onClick={() => setShowAddReservedForm((prev) => !prev)}
                  className="h-8 px-3 rounded-xl bg-white/6 border border-white/10 text-xs font-medium text-[#E2E6EE] hover:bg-white/10 transition-colors whitespace-nowrap"
                >
                  {showAddReservedForm ? t.cancel : t.addReservedToken}
                </button>
              </div>

              {showAddReservedForm && (
                <form
                  onSubmit={handleAddReservedToken}
                  className="p-3 rounded-xl bg-[#161922] border border-white/10 space-y-2.5"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={reservedName}
                      onChange={(e) => setReservedName(e.target.value)}
                      placeholder="Token Name (e.g. ELEVENLABS_KEY)"
                      required
                      className="h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                    />
                    <div className="flex items-center gap-1.5">
                      <input
                        type={showReservedValue ? 'text' : 'password'}
                        value={reservedValue}
                        onChange={(e) => setReservedValue(e.target.value)}
                        placeholder="Token Value"
                        required
                        autoComplete="off"
                        spellCheck={false}
                        className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs font-mono text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                      />
                      <button
                        type="button"
                        onClick={() => setShowReservedValue((s) => !s)}
                        aria-label="Toggle reserved token visibility"
                        className="h-10 w-10 shrink-0 flex items-center justify-center rounded-xl bg-[#0A0B0E] border border-white/10 text-[#9BA1AE] hover:text-white"
                      >
                        {showReservedValue ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="h-9 px-4 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 transition-colors"
                    >
                      Save Reserved Token
                    </button>
                  </div>
                </form>
              )}

              {vault.reservedTokens.length > 0 && (
                <div className="divide-y divide-white/8 border border-white/8 rounded-xl bg-[#0E1016] overflow-hidden">
                  {vault.reservedTokens.map((token) => {
                    const slotId = `reserved:${token.id}`;
                    const isShown = Boolean(revealed[slotId]);
                    return (
                      <div
                        key={token.id}
                        className="p-2.5 px-3 flex items-center justify-between gap-2"
                      >
                        <div className="min-w-0">
                          <div className="text-xs font-mono font-medium text-[#E5E8F0] truncate">
                            {token.name}
                          </div>
                          <div className="text-[11px] font-mono text-[#737A8A] truncate">
                            {isShown ? token.value : '••••••••••••••'}
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <StatusIndicator result={checkResults[slotId]} />
                          <button
                            type="button"
                            onClick={() => toggleReveal(slotId)}
                            aria-label={`Toggle ${token.name} visibility`}
                            className="h-8 w-8 flex items-center justify-center rounded-lg text-[#9BA1AE] hover:text-white hover:bg-white/6"
                          >
                            {isShown ? (
                              <EyeOff className="w-3.5 h-3.5" />
                            ) : (
                              <Eye className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemoveReservedToken(token.id)}
                            aria-label={`Remove ${token.name}`}
                            className="h-8 w-8 flex items-center justify-center rounded-lg text-[#9BA1AE] hover:text-rose-400 hover:bg-rose-500/10"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </section>
        </div>

        {/* Sticky Footer Bar */}
        <div className="shrink-0 px-4 py-3 border-t border-white/8 bg-[#141720] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-safe">
          <div className="flex items-center gap-2 text-xs text-[#9BA1AE] tabular-nums">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{configuredCount} configured</span>
            {summary.total > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400 font-medium">{summary.active} Active ✓</span>
                {summary.errors > 0 && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="text-rose-400 font-medium">{summary.errors} Error</span>
                  </>
                )}
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleTestAndConnectAll}
              disabled={isTesting}
              className="flex-1 sm:flex-none h-10 px-4 rounded-xl bg-white/8 border border-white/12 text-[#F4F5F7] text-xs font-semibold hover:bg-white/14 disabled:opacity-50 transition-colors inline-flex items-center justify-center gap-1.5 whitespace-nowrap"
            >
              {isTesting ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400" />
              ) : (
                <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
              )}
              {isTesting ? t.testingAll : t.testConnectAll}
            </button>

            <button
              type="button"
              onClick={() => {
                saveSecretsVault(vault);
                onEnterVeda();
              }}
              className="flex-1 sm:flex-none h-10 px-4 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 transition-colors whitespace-nowrap"
            >
              {t.enterVeda}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
