import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  BookOpen,
  Brain,
  Check,
  ChevronDown,
  Copy,
  Cpu,
  ExternalLink,
  FolderOpen,
  Globe,
  KeyRound,
  ListChecks,
  Loader2,
  Mic,
  Radio,
  Send,
  Volume2,
  VolumeX,
  Wrench,
  X,
} from 'lucide-react';
import { DEPARTMENT_META, UI_COPY } from '../i18n/translations';
import { BRAIN_OPTIONS } from '../services/aiRouter';
import { VOICE_PERSONAS, VOICE_SPEEDS } from '../services/cloudTtsService';
import { formatLockedPlanMarkdown } from '../services/vedaArchitectService';
import {
  BrainPreference,
  DepartmentId,
  DictationStatus,
  Language,
  LiveSessionStatus,
  LockedStepPlan,
  StudioProject,
  VedaMessage,
  VoicePersona,
  VoiceSettings,
  VoiceSpeed,
} from '../types/studio';

interface VedaHubProps {
  language: Language;
  projects: StudioProject[];
  messages: VedaMessage[];
  voiceSettings: VoiceSettings;
  brainPreference: BrainPreference;
  activeMemoryCount: number;
  thinkingPhase: 'idle' | 'researching' | 'thinking';
  speakingMessageId: string | null;
  dictationStatus: DictationStatus;
  interimTranscript: string;
  liveStatus: LiveSessionStatus;
  liveKeySlot?: number;
  voiceNotice: string | null;
  onDismissNotice: () => void;
  onSendMessage: (text: string) => void;
  onSelectDepartment: (department: DepartmentId) => void;
  onOpenProjects: (filter?: DepartmentId | 'all') => void;
  onOpenSecrets: () => void;
  onOpenMemory: () => void;
  onChangeBrainPreference: (brain: BrainPreference) => void;
  onSendPlanToDepartment: (plan: LockedStepPlan) => Promise<void>;
  onApproveDelegatedBuild: (department: 'gaming' | 'apps', nextStep: number) => void;
  onReviseDelegatedBuild: (department: 'gaming' | 'apps') => void;
  prefillDraft?: string | null;
  onClearPrefillDraft?: () => void;
  onToggleHandsFree: () => void;
  onToggleVoiceReply: () => void;
  onChangePersona: (persona: VoicePersona) => void;
  onChangeSpeed: (speed: VoiceSpeed) => void;
  onToggleLiveVoice: () => void;
  onReplayMessage: (message: VedaMessage) => void;
  onStopSpeech: () => void;
}

const DEPARTMENTS: DepartmentId[] = ['gaming', 'apps', 'bhojpuri', 'agent'];

function formatMsgTime(ts: number): string {
  try {
    return new Intl.DateTimeFormat(undefined, {
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(ts));
  } catch {
    return '';
  }
}

export const VedaHub: React.FC<VedaHubProps> = ({
  language,
  projects,
  messages,
  voiceSettings,
  brainPreference,
  activeMemoryCount,
  thinkingPhase,
  speakingMessageId,
  dictationStatus,
  interimTranscript,
  liveStatus,
  liveKeySlot,
  voiceNotice,
  onDismissNotice,
  onSendMessage,
  onSelectDepartment,
  onOpenProjects,
  onOpenSecrets,
  onOpenMemory,
  onChangeBrainPreference,
  onSendPlanToDepartment,
  onApproveDelegatedBuild,
  onReviseDelegatedBuild,
  prefillDraft,
  onClearPrefillDraft,
  onToggleHandsFree,
  onToggleVoiceReply,
  onChangePersona,
  onChangeSpeed,
  onToggleLiveVoice,
  onReplayMessage,
  onStopSpeech,
}) => {
  const t = UI_COPY[language];
  const [draft, setDraft] = useState('');
  const [openTray, setOpenTray] = useState<'none' | 'persona' | 'brain'>('none');
  const [copiedPlanId, setCopiedPlanId] = useState<string | null>(null);
  const [sendingPlanId, setSendingPlanId] = useState<string | null>(null);
  const transcriptEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (prefillDraft) {
      setDraft(prefillDraft);
      onClearPrefillDraft?.();
    }
  }, [prefillDraft, onClearPrefillDraft]);

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length, thinkingPhase]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = draft.trim();
    if (!cleaned || thinkingPhase !== 'idle') return;
    onSendMessage(cleaned);
    setDraft('');
  };

  const handleCopyPlan = async (plan: LockedStepPlan) => {
    const markdown = formatLockedPlanMarkdown(plan);
    try {
      await navigator.clipboard.writeText(markdown);
    } catch {
      // Fallback copy via textarea if clipboard API is restricted
      const el = document.createElement('textarea');
      el.value = markdown;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
    }
    setCopiedPlanId(plan.id);
    window.setTimeout(() => {
      setCopiedPlanId((curr) => (curr === plan.id ? null : curr));
    }, 1600);
  };

  const handleSendPlan = async (plan: LockedStepPlan) => {
    if (sendingPlanId) return;
    setSendingPlanId(plan.id);
    try {
      await onSendPlanToDepartment(plan);
    } finally {
      setSendingPlanId(null);
    }
  };

  const isLiveRunning = liveStatus !== 'idle';
  const isListening = dictationStatus === 'listening';
  const activeBrainLabel =
    BRAIN_OPTIONS.find((b) => b.id === brainPreference)?.label ?? 'Auto';

  return (
    <div className="h-full flex flex-col min-h-0 overflow-hidden">
      {/* Scrollable VEDA Gate Content + Transcript */}
      <div className="flex-1 min-h-0 overflow-y-auto studio-scroll">
        <div className="w-full max-w-5xl mx-auto px-3.5 sm:px-6 py-4 sm:py-6 space-y-6">
          {/* Welcome Heading */}
          <section className="space-y-1.5">
            <h1
              className="text-xl sm:text-2xl font-semibold tracking-tight text-[#F4F5F7] text-balance"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {t.vedaWelcomeTitle}
            </h1>
            <p className="text-xs sm:text-sm text-[#9BA1AE] max-w-2xl leading-relaxed">
              {t.vedaWelcomeSub}
            </p>
          </section>

          {/* Quick Department Switcher Cards */}
          <section aria-label={t.departmentSwitchers} className="space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-xs font-medium text-[#9BA1AE]">{t.departmentSwitchers}</h2>
              <span className="text-xs text-[#6F7686] tabular-nums">
                {projects.length} {t.projects.toLowerCase()}
              </span>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
              {DEPARTMENTS.map((dept) => {
                const meta = DEPARTMENT_META[dept];
                const deptCount = projects.filter((p) => p.department === dept).length;
                return (
                  <button
                    key={dept}
                    type="button"
                    onClick={() => onSelectDepartment(dept)}
                    className="group text-left p-3.5 sm:p-4 rounded-2xl studio-surface hover:bg-[#161922] hover:border-white/16 active:scale-[0.99] transition-all flex flex-col justify-between gap-3 min-h-[112px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/70"
                  >
                    <div className="space-y-1.5 min-w-0">
                      <div
                        className="text-sm font-semibold text-[#F4F5F7] leading-snug"
                        style={{ fontFamily: 'var(--font-display)' }}
                      >
                        {meta.cardTitle[language]}
                      </div>
                      <p className="text-[11px] sm:text-xs text-[#8D94A3] leading-relaxed line-clamp-2">
                        {meta.cardDescription[language]}
                      </p>
                    </div>

                    <div className="flex items-center justify-between gap-2 text-[11px] text-[#7D8596] pt-1 border-t border-white/6">
                      <span className="tabular-nums">
                        {deptCount} {t.projects.toLowerCase()}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#7D8596] group-hover:text-amber-400 group-hover:translate-x-0.5 transition-all shrink-0" />
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Clean Chat Transcript with Research Sources, Dynamic Skills, Locked Steps & 🔊 Replay */}
          <section className="space-y-3 pb-2" aria-label="VEDA Transcript">
            {messages.map((msg) => {
              const isUser = msg.role === 'user';
              const isThisSpeaking = speakingMessageId === msg.id;

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[94%] sm:max-w-[82%] rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm leading-relaxed ${
                      isUser
                        ? 'bg-amber-500/18 border border-amber-500/30 text-[#F8FAFC]'
                        : 'studio-surface text-[#E5E8F0]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3 mb-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="text-[11px] font-semibold text-[#9BA1AE]">
                          {isUser ? (language === 'hi' ? 'आप' : 'You') : 'VEDA'}
                        </span>
                        {!isUser && msg.providerUsed && (
                          <>
                            <span className="text-[10px] text-[#5F6676]" aria-hidden="true">
                              ·
                            </span>
                            <span className="text-[10px] text-[#8A92A3] truncate">
                              {msg.providerUsed}
                            </span>
                          </>
                        )}
                      </div>
                      <span className="text-[10px] font-mono text-[#6E7585] tabular-nums shrink-0">
                        {formatMsgTime(msg.timestamp)}
                      </span>
                    </div>

                    <p className="whitespace-pre-wrap break-words">{msg.text}</p>

                    {/* Silent Memory Learned Note */}
                    {!isUser && msg.learnedRuleSaved && (
                      <div className="mt-2 pt-2 border-t border-white/8 flex items-center gap-1.5 text-[11px] text-emerald-300/90">
                        <Brain className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">
                          {language === 'hi' ? 'मेमोरी में सेव:' : 'Saved to Memory:'}{' '}
                          {msg.learnedRuleSaved}
                        </span>
                      </div>
                    )}

                    {/* Dynamic API Skill Result Block */}
                    {!isUser && msg.savedSkill && (
                      <div className="mt-2.5 pt-2.5 border-t border-white/8 space-y-1.5">
                        <div className="flex items-center justify-between gap-2 text-[11px]">
                          <span className="inline-flex items-center gap-1.5 font-medium text-amber-300">
                            <Wrench className="w-3.5 h-3.5 shrink-0" />
                            {t.skillSavedLabel}
                          </span>
                          <span
                            className={`font-mono text-[10px] ${
                              msg.savedSkill.lastStatus === 'ok'
                                ? 'text-emerald-400'
                                : 'text-amber-300'
                            }`}
                          >
                            {msg.savedSkill.lastHttpStatus
                              ? `HTTP ${msg.savedSkill.lastHttpStatus}`
                              : msg.savedSkill.lastStatus}
                          </span>
                        </div>
                        <div className="text-[11px] font-mono text-[#9BA1AE] break-all">
                          {msg.savedSkill.method} {msg.savedSkill.url}
                        </div>
                        {msg.savedSkill.lastSnippet && (
                          <div className="text-[11px] font-mono text-[#C8CDD8] bg-[#0A0B0E] border border-white/8 rounded-lg p-2 break-words">
                            {msg.savedSkill.lastSnippet}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Clickable Live Web Research Sources */}
                    {!isUser && msg.sources && msg.sources.length > 0 && (
                      <div className="mt-2.5 pt-2.5 border-t border-white/8 space-y-1.5">
                        <div className="flex items-center gap-1.5 text-[11px] font-medium text-[#9BA1AE]">
                          <Globe className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span>{t.sourcesLabel}</span>
                        </div>
                        <ul className="space-y-1">
                          {msg.sources.map((src) => (
                            <li key={src.url} className="min-w-0">
                              <a
                                href={src.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1.5 text-[11px] text-amber-300 hover:text-amber-200 underline-offset-2 hover:underline max-w-full"
                              >
                                <span className="text-[#8A92A3] shrink-0">{src.provider} ·</span>
                                <span className="truncate">{src.title}</span>
                                <ExternalLink className="w-3 h-3 shrink-0 opacity-75" />
                              </a>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Interactive Locked Step Card with Copy & Send to Department */}
                    {!isUser && msg.lockedPlan && (
                      <div className="mt-3 pt-2.5 border-t border-white/8 space-y-2.5">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <ListChecks className="w-4 h-4 text-amber-400 shrink-0" />
                            <span
                              className="text-xs font-semibold text-[#F4F5F7] truncate"
                              style={{ fontFamily: 'var(--font-display)' }}
                            >
                              {msg.lockedPlan.title}
                            </span>
                          </div>
                          <span className="text-[11px] text-[#8D94A3]">
                            {t.lockedPlanLabel} ·{' '}
                            {DEPARTMENT_META[msg.lockedPlan.department].shortLabel[language]}
                          </span>
                        </div>

                        <ol className="space-y-2">
                          {msg.lockedPlan.steps.map((step) => (
                            <li
                              key={step.stepNumber}
                              className="flex items-start gap-2.5 text-xs bg-[#0B0D12] border border-white/8 rounded-xl p-2.5"
                            >
                              <span className="font-mono text-[11px] font-semibold text-amber-400 tabular-nums shrink-0 mt-0.5">
                                {String(step.stepNumber).padStart(2, '0')}.
                              </span>
                              <div className="min-w-0 space-y-0.5">
                                <div className="font-semibold text-[#F4F5F7]">{step.title}</div>
                                {step.detail && (
                                  <p className="text-[11px] text-[#9BA1AE] leading-relaxed">
                                    {step.detail}
                                  </p>
                                )}
                              </div>
                            </li>
                          ))}
                        </ol>

                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            type="button"
                            onClick={() => handleCopyPlan(msg.lockedPlan!)}
                            className="h-8 px-3 rounded-lg bg-white/8 border border-white/10 text-xs font-medium text-[#F4F5F7] hover:bg-white/14 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                          >
                            {copiedPlanId === msg.lockedPlan.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                <span>{t.copiedSteps}</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5 text-amber-400" />
                                <span>{t.copySteps}</span>
                              </>
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleSendPlan(msg.lockedPlan!)}
                            disabled={sendingPlanId === msg.lockedPlan.id}
                            className="h-8 px-3 rounded-lg bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 disabled:opacity-50 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                          >
                            <span>
                              {t.sendToDepartment} (
                              {DEPARTMENT_META[msg.lockedPlan.department].shortLabel[language]})
                            </span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Clarifying Department Choice Buttons */}
                    {!isUser && msg.clarifyRooms && msg.clarifyRooms.length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-white/8 flex items-center gap-1.5 flex-wrap">
                        {msg.clarifyRooms.map((dept) => (
                          <button
                            key={dept}
                            type="button"
                            onClick={() => onSelectDepartment(dept)}
                            className="h-8 px-3 rounded-lg bg-amber-500/16 border border-amber-400/35 text-amber-200 text-xs font-semibold hover:bg-amber-500/25 transition-colors inline-flex items-center gap-1 whitespace-nowrap"
                          >
                            <span>{DEPARTMENT_META[dept].cardTitle[language]}</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        ))}
                      </div>
                    )}

                    {/* VEDA Direct Department Delegation Actions (✅ Approve & Next Step / 🔄 बदलो) */}
                    {!isUser && msg.delegatedBuild && (
                      <div className="mt-2.5 pt-2 border-t border-white/8 flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() =>
                            onApproveDelegatedBuild(
                              msg.delegatedBuild!.department,
                              msg.delegatedBuild!.stepNumber + 1
                            )
                          }
                          className="h-8 px-3 rounded-lg bg-emerald-500/20 border border-emerald-400/45 text-emerald-200 text-xs font-semibold hover:bg-emerald-500/30 transition-colors whitespace-nowrap"
                        >
                          {t.approveNextStep}
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onReviseDelegatedBuild(msg.delegatedBuild!.department)
                          }
                          className="h-8 px-3 rounded-lg bg-white/8 border border-white/12 text-[#E5E8F0] text-xs font-medium hover:bg-white/14 transition-colors whitespace-nowrap"
                        >
                          {t.reviseBuild}
                        </button>
                        <button
                          type="button"
                          onClick={() => onSelectDepartment(msg.delegatedBuild!.department)}
                          className="h-8 px-2.5 rounded-lg bg-amber-500/16 border border-amber-400/35 text-amber-200 text-xs font-medium hover:bg-amber-500/24 transition-colors inline-flex items-center gap-1 whitespace-nowrap"
                        >
                          <span>{DEPARTMENT_META[msg.delegatedBuild.department].shortLabel[language]}</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    )}

                    {/* VEDA Message Footer (360px-safe): Room/Modal Action + Per-Message 🔊 सुनें / ⏹ रोकें Replay */}
                    {!isUser && (
                      <div className="mt-2.5 pt-2 border-t border-white/8 flex items-center justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {msg.actionRoom && (
                            <button
                              type="button"
                              onClick={() => onSelectDepartment(msg.actionRoom!)}
                              className="h-8 px-3 rounded-lg bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                            >
                              {DEPARTMENT_META[msg.actionRoom].cardTitle[language]}
                              <ArrowRight className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {msg.actionModal === 'secrets' && (
                            <button
                              type="button"
                              onClick={onOpenSecrets}
                              className="h-8 px-3 rounded-lg bg-white/10 text-[#F4F5F7] text-xs font-medium hover:bg-white/16 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                              {t.openSecrets}
                            </button>
                          )}

                          {msg.actionModal === 'projects' && (
                            <button
                              type="button"
                              onClick={() => onOpenProjects('all')}
                              className="h-8 px-3 rounded-lg bg-white/10 text-[#F4F5F7] text-xs font-medium hover:bg-white/16 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                              {t.openProjects}
                            </button>
                          )}

                          {msg.actionModal === 'memory' && (
                            <button
                              type="button"
                              onClick={onOpenMemory}
                              className="h-8 px-3 rounded-lg bg-white/10 text-[#F4F5F7] text-xs font-medium hover:bg-white/16 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                              {t.memoryTitle}
                            </button>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => (isThisSpeaking ? onStopSpeech() : onReplayMessage(msg))}
                          aria-label={isThisSpeaking ? t.stopMsg : t.listenMsg}
                          className={`h-8 px-3 rounded-full text-[11px] font-semibold transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0 ${
                            isThisSpeaking
                              ? 'bg-rose-500/20 border border-rose-400/45 text-rose-200 hover:bg-rose-500/30'
                              : 'bg-white/6 border border-white/10 text-[#D7DCE6] hover:bg-amber-500/15 hover:border-amber-400/35 hover:text-amber-200'
                          }`}
                        >
                          <span>{isThisSpeaking ? t.stopMsg : t.listenMsg}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Live Researching / Thinking Bubble */}
            {thinkingPhase !== 'idle' && (
              <div className="flex flex-col items-start">
                <div className="rounded-2xl px-3.5 py-2.5 studio-surface inline-flex items-center gap-2 text-xs text-[#C8CDD8]">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400 shrink-0" />
                  <span>
                    {thinkingPhase === 'researching' ? t.researchingNow : t.thinkingNow}
                  </span>
                </div>
              </div>
            )}

            <div ref={transcriptEndRef} />
          </section>
        </div>
      </div>

      {/* Docked Intelligence + Voice Controls + Input Bar (360px-safe, strictly above bottom nav) */}
      <div className="shrink-0 border-t border-white/8 bg-[#0D0F14]/95">
        <div className="w-full max-w-5xl mx-auto px-2.5 sm:px-6 pt-2 pb-2.5 space-y-2">
          {/* Subtle Non-Blocking Voice Notice or Live Interim Transcript */}
          {(voiceNotice || interimTranscript || isLiveRunning) && (
            <div className="flex items-center justify-between gap-2 px-3 py-1.5 rounded-xl bg-[#141720] border border-white/8 text-[11px] text-[#D1D5DF]">
              <div className="min-w-0 truncate">
                {isLiveRunning ? (
                  <span className="text-emerald-300 font-medium">
                    {liveStatus === 'connected'
                      ? `${t.liveActive}${liveKeySlot ? ` · Key ${liveKeySlot}` : ''} · ${voiceSettings.persona}`
                      : liveStatus === 'reconnecting'
                        ? `Rotating Gemini Live Key${liveKeySlot ? ` ${liveKeySlot}` : ''}...`
                        : `${t.liveConnecting}${liveKeySlot ? ` (Key ${liveKeySlot})` : ''}`}
                  </span>
                ) : interimTranscript ? (
                  <span className="text-amber-300">
                    {t.listeningNow} {interimTranscript}
                  </span>
                ) : (
                  <span className="text-amber-200/90">{voiceNotice}</span>
                )}
              </div>
              {voiceNotice && !isLiveRunning && !interimTranscript && (
                <button
                  type="button"
                  onClick={onDismissNotice}
                  aria-label="Dismiss voice notice"
                  className="p-0.5 text-[#8A92A3] hover:text-white shrink-0"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}

          {/* Inline Brain Selector Tray (Auto | Gemini | Groq | NVIDIA | Cloudflare) */}
          {openTray === 'brain' && (
            <div className="p-2.5 rounded-xl bg-[#141720] border border-white/10 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-medium text-[#9BA1AE]">
                  AI Router · Auto-Rotating Failover
                </span>
                <button
                  type="button"
                  onClick={() => setOpenTray('none')}
                  aria-label="Close brain selector tray"
                  className="p-0.5 text-[#8A92A3] hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                {BRAIN_OPTIONS.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      onChangeBrainPreference(opt.id);
                      setOpenTray('none');
                    }}
                    className={`h-8 px-3 rounded-lg text-[11px] font-medium transition-colors whitespace-nowrap ${
                      brainPreference === opt.id
                        ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                        : 'bg-[#0A0B0E] border border-white/10 text-[#C8CDD8] hover:text-white'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Inline Persona & Speed Picker Tray */}
          {openTray === 'persona' && (
            <div className="p-2.5 rounded-xl bg-[#141720] border border-white/10 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-medium text-[#9BA1AE]">
                  {t.voiceSettingsTitle}
                </span>
                <button
                  type="button"
                  onClick={() => setOpenTray('none')}
                  aria-label="Close voice persona tray"
                  className="p-0.5 text-[#8A92A3] hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                {VOICE_PERSONAS.map((persona) => (
                  <button
                    key={persona}
                    type="button"
                    onClick={() => onChangePersona(persona)}
                    className={`h-8 px-2.5 rounded-lg text-[11px] font-medium transition-colors whitespace-nowrap ${
                      voiceSettings.persona === persona
                        ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                        : 'bg-[#0A0B0E] border border-white/10 text-[#C8CDD8] hover:text-white'
                    }`}
                  >
                    {persona}
                  </button>
                ))}
                <span className="text-white/15 px-0.5" aria-hidden="true">
                  |
                </span>
                {VOICE_SPEEDS.map((spd) => (
                  <button
                    key={spd}
                    type="button"
                    onClick={() => onChangeSpeed(spd)}
                    className={`h-8 px-2 rounded-lg text-[11px] font-mono tabular-nums transition-colors whitespace-nowrap ${
                      voiceSettings.speed === spd
                        ? 'bg-amber-500/20 border border-amber-400/50 text-amber-200 font-semibold'
                        : 'bg-[#0A0B0E] border border-white/10 text-[#9BA1AE] hover:text-white'
                    }`}
                  >
                    {spd.toFixed(spd === 1 || spd === 1.5 ? 1 : 2)}x
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Compact 360px-safe Brain + Memory + Voice Controls Strip */}
          <div className="flex flex-wrap items-center gap-1.5">
            {/* Brain Selector Pill (Auto | Gemini | Groq | NVIDIA | Cloudflare) */}
            <button
              type="button"
              onClick={() => setOpenTray((prev) => (prev === 'brain' ? 'none' : 'brain'))}
              aria-expanded={openTray === 'brain'}
              className={`h-8 px-2.5 rounded-full text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0 border ${
                openTray === 'brain' || brainPreference !== 'auto'
                  ? 'bg-amber-500/18 border-amber-400/45 text-amber-200'
                  : 'bg-[#141720] border-white/10 text-[#C8CDD8] hover:text-white'
              }`}
            >
              <Cpu className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>{activeBrainLabel}</span>
              <ChevronDown
                className={`w-3 h-3 transition-transform ${openTray === 'brain' ? 'rotate-180' : ''}`}
              />
            </button>

            {/* Permanent Memory Pill */}
            <button
              type="button"
              onClick={onOpenMemory}
              className="h-8 px-2.5 rounded-full text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0 border bg-[#141720] border-white/10 text-[#C8CDD8] hover:text-white hover:border-amber-400/35 tabular-nums"
            >
              <Brain className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>{t.memoryLabel}</span>
              {activeMemoryCount > 0 && (
                <span className="font-mono text-[10px] text-amber-300">({activeMemoryCount})</span>
              )}
            </button>

            {/* 🎙️ Hands-Free Toggle */}
            <button
              type="button"
              onClick={onToggleHandsFree}
              aria-pressed={voiceSettings.handsFreeEnabled}
              className={`h-8 px-2.5 rounded-full text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0 border ${
                voiceSettings.handsFreeEnabled
                  ? 'bg-amber-500/20 border-amber-400/50 text-amber-200'
                  : 'bg-[#141720] border-white/10 text-[#B8BECB] hover:text-white'
              }`}
            >
              <Mic className="w-3.5 h-3.5 shrink-0" />
              <span>{isListening ? t.listeningNow : t.handsFree}</span>
            </button>

            {/* 🔊 Voice Reply Toggle */}
            <button
              type="button"
              onClick={onToggleVoiceReply}
              aria-pressed={voiceSettings.voiceReplyEnabled}
              className={`h-8 px-2.5 rounded-full text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0 border ${
                voiceSettings.voiceReplyEnabled
                  ? 'bg-amber-500/15 border-amber-400/40 text-amber-200'
                  : 'bg-[#141720] border-white/10 text-[#8E95A5] hover:text-white'
              }`}
            >
              {voiceSettings.voiceReplyEnabled ? (
                <Volume2 className="w-3.5 h-3.5 shrink-0" />
              ) : (
                <VolumeX className="w-3.5 h-3.5 shrink-0" />
              )}
              <span>{t.voiceReply}</span>
            </button>

            {/* Aoede Persona / Speed Pill */}
            <button
              type="button"
              onClick={() => setOpenTray((prev) => (prev === 'persona' ? 'none' : 'persona'))}
              aria-expanded={openTray === 'persona'}
              className={`h-8 px-2.5 rounded-full text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0 border tabular-nums ${
                openTray === 'persona'
                  ? 'bg-white/12 border-white/25 text-white'
                  : 'bg-[#141720] border-white/10 text-[#C8CDD8] hover:text-white'
              }`}
            >
              <span>
                {voiceSettings.persona} ·{' '}
                {voiceSettings.speed.toFixed(
                  voiceSettings.speed === 1 || voiceSettings.speed === 1.5 ? 1 : 2
                )}
                x
              </span>
              <ChevronDown
                className={`w-3 h-3 transition-transform ${
                  openTray === 'persona' ? 'rotate-180' : ''
                }`}
              />
            </button>

            {/* Live Voice / ■ Exit Live Button */}
            <button
              type="button"
              onClick={onToggleLiveVoice}
              className={`h-8 px-3 rounded-full text-[11px] font-semibold transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 ml-auto border ${
                isLiveRunning
                  ? 'bg-rose-600 border-rose-400/60 text-white hover:bg-rose-500'
                  : 'bg-emerald-500/14 border-emerald-400/35 text-emerald-300 hover:bg-emerald-500/22'
              }`}
            >
              {isLiveRunning ? (
                <span>{t.exitLive}</span>
              ) : (
                <>
                  <Radio className="w-3.5 h-3.5 shrink-0" />
                  <span>{t.liveVoice}</span>
                </>
              )}
            </button>
          </div>

          {/* Chat Input Form */}
          <form onSubmit={handleSubmit} className="flex items-center gap-2">
            <input
              type="text"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder={t.vedaInputPlaceholder}
              aria-label={t.vedaInputPlaceholder}
              className="flex-1 min-w-0 h-11 px-3.5 rounded-xl bg-[#141720] border border-white/10 text-xs sm:text-sm text-[#F4F5F7] placeholder:text-[#666D7D] focus:outline-none focus:border-amber-400/70 transition-colors"
            />
            <button
              type="submit"
              disabled={!draft.trim() || thinkingPhase !== 'idle'}
              aria-label={t.send}
              className="h-11 px-4 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs sm:text-sm font-semibold hover:bg-amber-400 disabled:opacity-40 transition-colors inline-flex items-center justify-center gap-1.5 shrink-0 whitespace-nowrap"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">{t.send}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
