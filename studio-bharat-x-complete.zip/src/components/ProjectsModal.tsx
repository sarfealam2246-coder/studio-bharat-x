import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  FolderOpen,
  Pencil,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { DEPARTMENT_META, UI_COPY } from '../i18n/translations';
import {
  createProject,
  deleteProject,
  getStorageBackend,
  renameProject,
} from '../services/projectStoreService';
import { DepartmentId, Language, StudioProject } from '../types/studio';

interface ProjectsModalProps {
  isOpen: boolean;
  language: Language;
  projects: StudioProject[];
  initialFilter?: DepartmentId | 'all';
  onClose: () => void;
  onSelectProject: (project: StudioProject) => void;
  onProjectsMutated: () => Promise<void>;
}

const DEPARTMENTS: DepartmentId[] = ['gaming', 'apps', 'bhojpuri', 'agent'];

function formatTimestamp(ts: number): string {
  try {
    return new Intl.DateTimeFormat(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(ts));
  } catch {
    return '';
  }
}

export const ProjectsModal: React.FC<ProjectsModalProps> = ({
  isOpen,
  language,
  projects,
  initialFilter = 'all',
  onClose,
  onSelectProject,
  onProjectsMutated,
}) => {
  const t = UI_COPY[language];
  const [filter, setFilter] = useState<DepartmentId | 'all'>(initialFilter);
  const [query, setQuery] = useState('');
  const [newName, setNewName] = useState('');
  const [newDepartment, setNewDepartment] = useState<DepartmentId>(
    initialFilter === 'all' ? 'gaming' : initialFilter
  );
  const [isCreating, setIsCreating] = useState(false);

  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameDraft, setRenameDraft] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setFilter(initialFilter);
      setNewDepartment(initialFilter === 'all' ? 'gaming' : initialFilter);
      setRenamingId(null);
      setConfirmDeleteId(null);
    }
  }, [isOpen, initialFilter]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  const filteredProjects = useMemo(() => {
    const q = query.trim().toLowerCase();
    return projects.filter((project) => {
      if (filter !== 'all' && project.department !== filter) return false;
      if (!q) return true;
      return (
        project.name.toLowerCase().includes(q) ||
        project.department.toLowerCase().includes(q) ||
        project.files.some((f) => f.path.toLowerCase().includes(q))
      );
    });
  }, [projects, filter, query]);

  if (!isOpen) return null;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newName.trim();
    if (!trimmed || isCreating) return;
    setIsCreating(true);
    try {
      const created = await createProject({
        name: trimmed,
        department: newDepartment,
      });
      await onProjectsMutated();
      setNewName('');
      onSelectProject(created);
      onClose();
    } finally {
      setIsCreating(false);
    }
  };

  const handleRenameSubmit = async (projectId: string) => {
    if (!renameDraft.trim()) {
      setRenamingId(null);
      return;
    }
    await renameProject(projectId, renameDraft.trim());
    await onProjectsMutated();
    setRenamingId(null);
  };

  const handleDeleteConfirm = async (project: StudioProject) => {
    await deleteProject(project.id, project.department);
    await onProjectsMutated();
    setConfirmDeleteId(null);
  };

  const backendLabel = getStorageBackend() === 'indexeddb' ? 'IndexedDB' : 'LocalStorage Fallback';

  return (
    <div
      className="fixed inset-0 z-[55] flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="projects-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-2xl max-h-[90dvh] flex flex-col rounded-t-2xl sm:rounded-2xl bg-[#111319] border border-white/10 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="shrink-0 flex items-center justify-between gap-3 px-4 py-3.5 border-b border-white/8 bg-[#141720]">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <FolderOpen className="w-4 h-4 text-amber-400 shrink-0" />
              <h2
                id="projects-modal-title"
                className="text-base font-semibold text-[#F4F5F7] truncate"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {t.projectsTitle}
              </h2>
            </div>
            <p className="text-xs text-[#9BA1AE] mt-0.5">
              {t.projectsSubtitle} · <span className="font-mono text-[#B7BDC9]">{backendLabel}</span>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close projects modal"
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-[#9BA1AE] hover:text-white hover:bg-white/6 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Create New Project Bar */}
        <form
          onSubmit={handleCreate}
          className="shrink-0 p-3.5 border-b border-white/8 bg-[#13161E] flex flex-col sm:flex-row gap-2"
        >
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder={`${t.newProject}...`}
            className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
          />
          <div className="flex items-center gap-2">
            <select
              aria-label="Project Department"
              value={newDepartment}
              onChange={(e) => setNewDepartment(e.target.value as DepartmentId)}
              className="flex-1 sm:flex-none h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs text-[#F4F5F7] focus:outline-none focus:border-amber-400/70"
            >
              {DEPARTMENTS.map((dept) => (
                <option key={dept} value={dept}>
                  {DEPARTMENT_META[dept].emoji} {DEPARTMENT_META[dept].shortLabel[language]}
                </option>
              ))}
            </select>
            <button
              type="submit"
              disabled={!newName.trim() || isCreating}
              className="h-10 px-4 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 disabled:opacity-40 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              {t.create}
            </button>
          </div>
        </form>

        {/* Filter & Search Bar */}
        <div className="shrink-0 px-4 py-3 border-b border-white/8 space-y-2.5">
          <div className="relative">
            <Search className="w-4 h-4 text-[#737A8A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.searchProjects}
              className="w-full h-9 pl-9 pr-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`h-8 px-3 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                filter === 'all'
                  ? 'bg-amber-500/18 text-amber-300'
                  : 'text-[#9BA1AE] hover:text-white hover:bg-white/5'
              }`}
            >
              {t.allDepartments} ({projects.length})
            </button>
            {DEPARTMENTS.map((dept) => {
              const count = projects.filter((p) => p.department === dept).length;
              return (
                <button
                  key={dept}
                  type="button"
                  onClick={() => setFilter(dept)}
                  className={`h-8 px-3 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 tabular-nums ${
                    filter === dept
                      ? 'bg-amber-500/18 text-amber-300'
                      : 'text-[#9BA1AE] hover:text-white hover:bg-white/5'
                  }`}
                >
                  {DEPARTMENT_META[dept].shortLabel[language]} ({count})
                </button>
              );
            })}
          </div>
        </div>

        {/* Project List */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll p-4 pb-safe">
          {filteredProjects.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <p className="text-sm text-[#9BA1AE]">{t.emptyProjects}</p>
            </div>
          ) : (
            <div className="divide-y divide-white/8 border border-white/8 rounded-xl bg-[#0E1016] overflow-hidden">
              {filteredProjects.map((project) => {
                const meta = DEPARTMENT_META[project.department];
                const isRenaming = renamingId === project.id;
                const isDeleting = confirmDeleteId === project.id;

                return (
                  <div
                    key={project.id}
                    className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-white/[0.02] transition-colors"
                  >
                    <div className="min-w-0 flex-1">
                      {isRenaming ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={renameDraft}
                            onChange={(e) => setRenameDraft(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleRenameSubmit(project.id);
                              if (e.key === 'Escape') setRenamingId(null);
                            }}
                            autoFocus
                            className="flex-1 min-w-0 h-8 px-2.5 rounded-lg bg-[#0A0B0E] border border-amber-400/60 text-xs text-[#F4F5F7] focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleRenameSubmit(project.id)}
                            aria-label="Save new name"
                            className="h-8 w-8 flex items-center justify-center rounded-lg bg-amber-500 text-[#0A0B0E]"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setRenamingId(null)}
                            aria-label="Cancel rename"
                            className="h-8 w-8 flex items-center justify-center rounded-lg bg-white/6 text-[#9BA1AE]"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <div className="text-sm font-medium text-[#F4F5F7] truncate">
                            {project.name}
                          </div>
                          <div className="flex items-center gap-1.5 text-xs text-[#8D94A3] mt-0.5 tabular-nums flex-wrap">
                            <span className={meta.accentClass}>
                              {meta.shortLabel[language]}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>
                              {project.files.length} {t.filesCount}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono text-[11px]">
                              {formatTimestamp(project.updatedAt)}
                            </span>
                          </div>
                        </>
                      )}
                    </div>

                    {!isRenaming && (
                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                        {isDeleting ? (
                          <>
                            <button
                              type="button"
                              onClick={() => handleDeleteConfirm(project)}
                              className="h-8 px-3 rounded-lg bg-rose-500 text-white text-xs font-medium hover:bg-rose-400 transition-colors"
                            >
                              {t.confirmDelete}
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="h-8 px-2.5 rounded-lg bg-white/8 text-xs text-[#D1D5DF] hover:bg-white/14"
                            >
                              {t.cancel}
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                onSelectProject(project);
                                onClose();
                              }}
                              className="h-8 px-3 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-medium hover:bg-amber-500/25 transition-colors whitespace-nowrap"
                            >
                              {t.open}
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setRenamingId(project.id);
                                setRenameDraft(project.name);
                                setConfirmDeleteId(null);
                              }}
                              aria-label={`${t.rename} ${project.name}`}
                              className="h-8 w-8 flex items-center justify-center rounded-lg text-[#9BA1AE] hover:text-white hover:bg-white/6"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(project.id)}
                              aria-label={`${t.delete} ${project.name}`}
                              className="h-8 w-8 flex items-center justify-center rounded-lg text-[#9BA1AE] hover:text-rose-400 hover:bg-rose-500/10"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
